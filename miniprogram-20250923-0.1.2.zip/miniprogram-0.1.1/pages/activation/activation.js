// 引入云开发数据库集合 
const { activationCodeCollection } = require('../../utils/cloud');
 
Page({
  data: {
    activationCode: '', // 存储激活码输入值
    showProductText: false, // 控制购买商品文本的显示/隐藏
    productText: '【小红书】3E · 天赋分析服务 😆 A1FnJkyyVEJ 😆 https://xhslink.com/m/ef95G4WJHE 点击链接或者复制本条信息打开【小红书app】查看 CZ3265', // 要显示和复制的商品文本
    isSubmitted: null // 新增数据isSubmitted，初始值为null
  },
 
  // 输入框内容变化事件
  onInputChange(e) {
    let code = e.detail.value.replace(/\s+/g,  ''); // 移除空格
    this.setData({  activationCode: code });
  },
 
  // 激活码验证主函数
  handleActivation() {
    const { activationCode } = this.data; 
 
    // 校验激活码是否为16位 
    if (!activationCode || activationCode.length  !== 16) {
      wx.showToast({ 
        title: '请输入16位激活码',
        icon: 'none',
        duration: 2000
      });
      return;
    }
 
    // 显示加载动画 
    wx.showLoading({
      title: '验证中...',
      mask: true 
    });
 
    // 查询数据库，注意字段名匹配
    activationCodeCollection
      .where({
        activationCode: activationCode // 注意字段名是 activationCode
      })
      .get()
      .then(res => {
        wx.hideLoading(); 
 
        if (res.data.length  === 0) {
          // 激活码不存在
          wx.showToast({ 
            title: '激活码不存在',
            icon: 'none',
            duration: 1000 
          });
          return;
        }
 
        const codeInfo = res.data[0];  // 获取激活码信息
        console.log('查询到的激活码信息:', codeInfo);
 
        // 格式化当前时间为YYYY-MM-DD HH:mm:ss格式
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        const seconds = String(now.getSeconds()).padStart(2, '0');
        const formattedTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
        
        console.log('准备更新的激活码ID:', codeInfo._id);
        
        if (codeInfo.isSubmitted === null) {
          // 激活码未使用：直接跳转到支付成功页面
          console.log('激活码未使用，直接跳转');
          wx.navigateTo({ 
            url: `/pages/payment-success/payment-success?activationCode=${encodeURIComponent(activationCode)}`
          });
        } else if (codeInfo.isSubmitted === true) {
          // 激活码已使用：跳转到结果/result页面并且传递激活码和数据isSubmitted
          wx.navigateTo({ 
            url: `/pages/result/result?activationCode=${encodeURIComponent(activationCode)}&isSubmitted=true` 
          });
        }
      })
      .catch(err => {
        wx.hideLoading(); 
        wx.showToast({ 
          title: '网络异常，请重试',
          icon: 'none',
          duration: 2000
        });
        console.error(' 激活码验证失败：', err);
      });
  },

  // 购买商品按钮点击事件
  handleProductPurchase() {
    // 显示购买商品文本区域
    this.setData({
      showProductText: true
    });
  },

  // 复制商品文本
  copyProductText() {
    const { productText } = this.data;
    // 使用微信提供的复制API
    wx.setClipboardData({
      data: productText,
      success: () => {
        wx.showToast({
          title: '复制成功',
          icon: 'success',
          duration: 2000
        });
      },
      fail: () => {
        wx.showToast({
          title: '复制失败',
          icon: 'none',
          duration: 2000
        });
      }
    });
  },

  // 分享给朋友
  onShareAppMessage: function() {
    return {
      title: '输入高光时刻，发现独特天赋！',
      path: '/pages/index/index',
      imageUrl: '', // 可以添加分享图片路径
      success: function(res) {
        console.log('分享成功', res);
      },
      fail: function(res) {
        console.log('分享失败', res);
      }
    };
  },

  // 分享到朋友圈
  onShareTimeline: function() {
    return {
      title: '每个人都有独特天赋，输入高光时刻，解锁专属分析报告', 
      query: 'share=true',
      path: '/pages/index/index',
      imageUrl: '' // 可以添加分享图片路径
    };
  }

});