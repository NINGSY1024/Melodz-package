// index.js
// 首页页面逻辑文件
// 主要功能：作为应用入口，引导用户开始天赋探索之旅
Page({
  /**
   * 跳转到activation页面
   * 功能：点击按钮后，导航到天赋激活页面
   * 异常处理：包含成功和失败的回调处理，失败时会显示提示信息
   */
  navigateToActivation() {
    wx.navigateTo({
      url: '/pages/activation/activation', // 使用绝对路径更可靠
      success: () => console.log(' 跳转成功'),
      fail: (err) => {
        console.error(' 跳转失败:', err)
        wx.showToast({ 
          title: '跳转失败',
          icon: 'none' // 不显示图标，仅显示文本
        })
      }
    })
  }
})
