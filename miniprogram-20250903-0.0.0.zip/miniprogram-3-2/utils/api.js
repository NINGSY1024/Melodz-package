// 小程序版天赋分析API服务
const API_CONFIG = {
  // 使用deepseek API作为后端
  baseUrl: 'https://api.deepseek.com/v1',
  apiKey: 'sk-1f9f63a1363543c8ac2b8cd52400989d',
  model: 'deepseek-chat'
};

// 天赋数据库（模拟web版的TALENT_DATABASE）
const TALENT_DATABASE = [
  { id: '1', name: '逻辑思维', category: '认知能力', description: '理性分析问题能力' },
  { id: '2', name: '领导力', category: '人际交往', description: '带领团队达成目标' },
  { id: '3', name: '创新思维', category: '创造能力', description: '创造性解决问题' },
  { id: '4', name: '沟通能力', category: '人际交往', description: '有效传达信息' },
  { id: '5', name: '执行力', category: '执行能力', description: '高效完成任务' },
  { id: '6', name: '学习能力', category: '认知能力', description: '快速掌握新知识' },
  { id: '7', name: '团队合作', category: '人际交往', description: '与他人协作配合' },
  { id: '8', name: '抗压能力', category: '情感智慧', description: '承受压力的能力' },
  { id: '9', name: '创造力', category: '创造能力', description: '产生新颖想法' },
  { id: '10', name: '责任心', category: '情感智慧', description: '承担责任的态度' }
];

// 30位高学历女性崇拜的海内外名人数据库
const CELEBRITY_DATABASE = [
  // 科技与创新女性领袖
  { 
    name: '董明珠', 
    description: '格力电器董事长', 
    avatar: '👩‍💼',
    talents: ['领导力', '决策能力', '抗压能力'],
    achievements: ['格力电器转型', '中国制造品牌', '女性企业家典范']
  },
  { 
    name: '谢丽尔·桑德伯格', 
    description: 'Facebook前COO', 
    avatar: '👩‍💻',
    talents: ['领导力', '沟通能力', '创新思维'],
    achievements: ['Facebook商业化', '《向前一步》作者', '女性领导力倡导']
  },
  { 
    name: '苏珊·沃西基', 
    description: 'YouTube前CEO', 
    avatar: '👩‍🎬',
    talents: ['创新思维', '学习能力', '执行力'],
    achievements: ['YouTube发展', '谷歌广告业务', '科技女性领袖']
  },
  { 
    name: '李飞飞', 
    description: '斯坦福AI实验室主任', 
    avatar: '🤖',
    talents: ['研究能力', '逻辑思维', '创新思维'],
    achievements: ['ImageNet数据集', 'AI研究突破', '人工智能伦理']
  },
  { 
    name: '吉尼·罗梅蒂', 
    description: 'IBM前CEO', 
    avatar: '👩‍🔬',
    talents: ['领导力', '学习能力', '决策能力'],
    achievements: ['IBM转型', '人工智能推广', '技术女性领导']
  },

  // 学术与科学研究领域
  { 
    name: '屠呦呦', 
    description: '诺贝尔医学奖获得者', 
    avatar: '🏆',
    talents: ['研究能力', '抗压能力', '学习能力'],
    achievements: ['诺贝尔医学奖', '青蒿素发现', '疟疾治疗突破']
  },
  { 
    name: '玛丽·居里', 
    description: '物理学家、化学家', 
    avatar: '⚗️',
    talents: ['研究能力', '抗压能力', '逻辑思维'],
    achievements: ['两次诺贝尔奖', '放射性研究', '科学女性先驱']
  },
  { 
    name: '简·古道尔', 
    description: '灵长类动物学家', 
    avatar: '🦍',
    talents: ['研究能力', '观察能力', '沟通能力'],
    achievements: ['黑猩猩研究', '环保倡导', '科学传播']
  },
  { 
    name: '罗莎琳·富兰克林', 
    description: 'DNA结构发现者', 
    avatar: '🧬',
    talents: ['研究能力', '逻辑思维', '创新思维'],
    achievements: ['DNA双螺旋结构', 'X射线晶体学', '分子生物学贡献']
  },
  { 
    name: '多萝西·霍奇金', 
    description: '结构化学家', 
    avatar: '🔬',
    talents: ['研究能力', '逻辑思维', '抗压能力'],
    achievements: ['诺贝尔化学奖', 'X射线晶体学', '蛋白质结构研究']
  },

  // 社会影响与公益领域
  { 
    name: '马拉拉·优素福扎伊', 
    description: '诺贝尔和平奖获得者', 
    avatar: '🕊️',
    talents: ['沟通能力', '抗压能力', '领导力'],
    achievements: ['诺贝尔和平奖', '教育权益倡导', '全球青年领袖']
  },
  { 
    name: '米歇尔·奥巴马', 
    description: '前美国第一夫人', 
    avatar: '👑',
    talents: ['沟通能力', '领导力', '情商管理'],
    achievements: ['第一夫人', '教育倡导', '《成为》作者']
  },
  { 
    name: '梅琳达·盖茨', 
    description: '慈善家', 
    avatar: '💝',
    talents: ['组织能力', '沟通能力', '决策能力'],
    achievements: ['盖茨基金会', '全球健康倡导', '女性赋权']
  },
  { 
    name: '奥普拉·温弗瑞', 
    description: '媒体女王', 
    avatar: '🎤',
    talents: ['沟通能力', '情商管理', '领导力'],
    achievements: ['脱口秀女王', '媒体帝国', '慈善事业']
  },
  { 
    name: '杨澜', 
    description: '媒体人、慈善家', 
    avatar: '📺',
    talents: ['沟通能力', '跨文化交流', '组织能力'],
    achievements: ['阳光媒体集团', '国际传播', '慈善事业']
  },

  // 商业与创业领域
  { 
    name: '惠特尼·沃尔夫·赫德', 
    description: 'Bumble创始人', 
    avatar: '💕',
    talents: ['创新思维', '领导力', '沟通能力'],
    achievements: ['Bumble创立', '女性赋权平台', '最年轻女CEO上市']
  },
  { 
    name: '萨拉·布莱克利', 
    description: 'Spanx创始人', 
    avatar: '👗',
    talents: ['创新思维', '抗压能力', '执行力'],
    achievements: ['Spanx品牌', '白手起家', '女性创业典范']
  },
  { 
    name: '梅兰妮·珀金斯', 
    description: 'Canva创始人', 
    avatar: '🎨',
    talents: ['创新思维', '设计能力', '抗压能力'],
    achievements: ['Canva创立', '设计工具普及', '创业坚持']
  },
  { 
    name: '卡特里娜·莱克', 
    description: 'Stitch Fix创始人', 
    avatar: '📊',
    talents: ['数据分析', '创新思维', '学习能力'],
    achievements: ['Stitch Fix', '个性化推荐', '数据驱动商业']
  },
  { 
    name: '英德拉·努伊', 
    description: '百事公司前CEO', 
    avatar: '🥤',
    talents: ['领导力', '决策能力', '学习能力'],
    achievements: ['百事公司转型', '可持续发展', '多元化领导']
  },

  // 文化与艺术领域
  { 
    name: '安娜·温图尔', 
    description: 'Vogue主编', 
    avatar: '👠',
    talents: ['审美能力', '领导力', '沟通能力'],
    achievements: ['Vogue杂志', '时尚产业影响', 'Met Gala策划']
  },
  { 
    name: '碧昂丝', 
    description: '歌手、商业女强人', 
    avatar: '🎵',
    talents: ['艺术表达', '创新思维', '领导力'],
    achievements: ['格莱美奖', '商业帝国', '女性赋权']
  },
  { 
    name: '扎哈·哈迪德', 
    description: '建筑女王', 
    avatar: '🏗️',
    talents: ['创意思维', '设计能力', '抗压能力'],
    achievements: ['普利兹克建筑奖', '解构主义建筑', '突破性设计']
  },
  { 
    name: '朗朗', 
    description: '钢琴家', 
    avatar: '🎹',
    talents: ['艺术表达', '学习能力', '情商管理'],
    achievements: ['国际钢琴家', '音乐教育', '文化交流']
  },

  // 法律与政治领域
  { 
    name: '鲁思·巴德·金斯伯格', 
    description: '美国最高法院大法官', 
    avatar: '⚖️',
    talents: ['逻辑思维', '沟通能力', '抗压能力'],
    achievements: ['最高法院大法官', '性别平等倡导', '法律先驱']
  },
  { 
    name: '希拉里·克林顿', 
    description: '前美国国务卿', 
    avatar: '🏛️',
    talents: ['领导力', '沟通能力', '决策能力'],
    achievements: ['国务卿', '参议员', '女性政治先驱']
  },
  { 
    name: '安吉拉·默克尔', 
    description: '德国前总理', 
    avatar: '🇩🇪',
    talents: ['领导力', '决策能力', '抗压能力'],
    achievements: ['德国总理', '欧盟领导', '危机管理']
  },

  // 医学与健康领域
  { 
    name: '陈薇', 
    description: '军事医学专家', 
    avatar: '💉',
    talents: ['研究能力', '抗压能力', '组织能力'],
    achievements: ['疫苗研发', '生物安全', '军事医学']
  },
  { 
    name: '珍妮弗·道德纳', 
    description: 'CRISPR技术发明者', 
    avatar: '🧬',
    talents: ['研究能力', '创新思维', '逻辑思维'],
    achievements: ['诺贝尔化学奖', 'CRISPR技术', '基因编辑突破']
  },
  { 
    name: '弗朗西斯·阿诺德', 
    description: '化学工程师', 
    avatar: '🧪',
    talents: ['研究能力', '创新思维', '学习能力'],
    achievements: ['诺贝尔化学奖', '酶的定向进化', '绿色化学']
  }
];

/**
 * 分析高光时刻（模拟web版analyze-highlights）
 * @param {Array} highlights - 高光时刻数组
 * @param {string} userId - 用户ID
 * @returns {Promise} - 返回分析结果
 */
function analyzeHighlights(highlights, userId) {
  return new Promise((resolve, reject) => {
    if (!highlights || highlights.length === 0) {
      reject(new Error('请提供至少一个高光时刻'));
      return;
    }

    const validHighlights = highlights.filter(h => h.trim() !== '');
    
    // 模拟AI分析过程
    setTimeout(() => {
      try {
        const analysisResult = generateMockAnalysis(validHighlights, userId);
        resolve(analysisResult);
      } catch (error) {
        reject(error);
      }
    }, 1500);
  });
}

/**
 * 生成模拟分析数据（基于web版逻辑）
 */
function generateMockAnalysis(highlights, userId) {
  const analysis = highlights.map((highlight, index) => {
    // 根据高光内容智能匹配天赋
    const matchedTalents = matchTalentsToHighlight(highlight);
    return {
      moment: highlight,
      talents: matchedTalents
    };
  });

  // 统计所有天赋
  const allTalents = analysis.flatMap(item => item.talents);
  
  // 计算天赋频率
  const talentCounts = {};
  allTalents.forEach(talent => {
    talentCounts[talent] = (talentCounts[talent] || 0) + 1;
  });

  // 排序并生成统计数据
  const sortedTalents = Object.entries(talentCounts)
    .sort(([,a], [,b]) => b - a)
    .map(([talent, count]) => ({
      talent,
      count,
      percentage: Number(((count / allTalents.length) * 100).toFixed(1))
    }));

  // 生成词云数据
  const wordCloudData = sortedTalents.map(({ talent, count }) => ({
    text: talent,
    value: count,
    frequency: Number(((count / allTalents.length) * 100).toFixed(1))
  }));

  // 获取前3名天赋
  const topThreeTalents = sortedTalents.slice(0, 3);

  // 名人匹配
  const celebrities = matchCelebrities(topThreeTalents.map(t => t.talent));

  // 聚类分析
  const clusters = performClustering(sortedTalents);

  return {
    userId,
    analysis,
    allTalents,
    statistics: {
      totalTalents: allTalents.length,
      uniqueTalents: sortedTalents.length,
      topTalents: topThreeTalents,
      frequencyDistribution: sortedTalents,
      clusters
    },
    wordCloud: wordCloudData,
    celebrities,
    summary: {
      totalMoments: highlights.length,
      totalTalents: allTalents.length,
      uniqueTalents: sortedTalents.length,
      mostFrequentTalent: sortedTalents[0]
    }
  };
}

/**
 * 根据高光内容匹配天赋
 */
function matchTalentsToHighlight(highlight) {
  const talentMap = {
    '领导': ['领导力', '团队合作', '沟通能力'],
    '组织': ['组织能力', '执行力', '团队合作'],
    '创新': ['创新思维', '创造力', '学习能力'],
    '学习': ['学习能力', '逻辑思维', '创造力'],
    '沟通': ['沟通能力', '团队合作', '领导力'],
    '解决': ['逻辑思维', '创新思维', '执行力'],
    '压力': ['抗压能力', '责任心', '执行力'],
    '团队': ['团队合作', '领导力', '沟通能力'],
    '数学': ['逻辑思维', '学习能力', '创造力'],
    '演讲': ['沟通能力', '领导力', '创造力']
  };

  const matched = [];
  Object.keys(talentMap).forEach(keyword => {
    if (highlight.includes(keyword)) {
      matched.push(...talentMap[keyword]);
    }
  });

  // 去重并限制为5个
  const uniqueTalents = [...new Set(matched)];
  return uniqueTalents.slice(0, 5).length > 0 ? uniqueTalents.slice(0, 5) : 
         ['学习能力', '执行力', '责任心', '团队合作', '创新思维'];
}

/**
 * 名人匹配逻辑
 */
function matchCelebrities(userTalents) {
  return CELEBRITY_DATABASE.filter(celebrity => 
    celebrity.talents.some(talent => userTalents.includes(talent))
  ).map(celebrity => ({
    ...celebrity,
    matchRate: Math.round((celebrity.talents.filter(t => userTalents.includes(t)).length / celebrity.talents.length) * 100)
  })).sort((a, b) => b.matchRate - a.matchRate).slice(0, 3);
}

/**
 * 聚类分析（模拟web版逻辑）
 */
function performClustering(talents) {
  const categories = {
    '认知能力': ['逻辑思维', '学习能力', '创造力'],
    '人际交往': ['领导力', '沟通能力', '团队合作'],
    '执行能力': ['执行力', '组织能力', '抗压能力'],
    '情感智慧': ['责任心', '抗压能力', '沟通能力']
  };

  const clusters = [];
  Object.entries(categories).forEach(([category, categoryTalents]) => {
    const matched = talents.filter(t => categoryTalents.includes(t.talent));
    if (matched.length > 0) {
      clusters.push({
        cluster: category,
        talents: matched.map(t => t.talent),
        frequency: matched.reduce((sum, t) => sum + t.count, 0)
      });
    }
  });

  return clusters.sort((a, b) => b.frequency - a.frequency);
}

/**
 * 获取天赋统计数据（模拟talent-statistics API）
 */
function getTalentStatistics(analysisData) {
  return new Promise((resolve) => {
    setTimeout(() => {
      const stats = {
        statistics: analysisData.statistics,
        wordCloud: analysisData.wordCloud,
        topThreeTalents: analysisData.statistics.topTalents,
        clusters: analysisData.statistics.clusters,
        summary: analysisData.summary
      };
      resolve(stats);
    }, 500);
  });
}

module.exports = {
  analyzeHighlights,
  getTalentStatistics,
  TALENT_DATABASE,
  CELEBRITY_DATABASE
};