// 引入云开发数据库集合 
const { activationCodeCollection } = require('../../utils/cloud');
 
Page({
  data: {
    activationCode: '' // 存储激活码输入值
  },
 
  // 输入框内容变化事件
  onInputChange(e) {
    let code = e.detail.value.replace(/\s+/g,  ''); // 移除空格
    this.setData({  activationCode: code });
  },
 
  // 激活码验证主函数
  handleActivation() {
    const { activationCode } = this.data; 
 
    // 校验激活码是否为16位 
    if (!activationCode || activationCode.length  !== 16) {
      wx.showToast({ 
        title: '请输入16位激活码',
        icon: 'none',
        duration: 2000
      });
      return;
    }
 
    // 显示加载动画 
    wx.showLoading({
      title: '验证中...',
      mask: true 
    });
 
    // 查询数据库，注意字段名匹配
    activationCodeCollection
      .where({
        activationCode: activationCode // 注意字段名是 activationCode
      })
      .get()
      .then(res => {
        wx.hideLoading(); 
 
        if (res.data.length  === 0) {
          // 激活码不存在
          wx.showToast({ 
            title: '激活码不存在',
            icon: 'none',
            duration: 1000 
          });
          return;
        }
 
        const codeInfo = res.data[0];  // 获取激活码信息
        console.log('查询到的激活码信息:', codeInfo);
 
        // 格式化当前时间为YYYY-MM-DD HH:mm:ss格式
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        const seconds = String(now.getSeconds()).padStart(2, '0');
        const formattedTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
        
        console.log('准备更新的激活码ID:', codeInfo._id);
        console.log('准备设置的激活状态:', true);
        console.log('准备设置的激活时间:', formattedTime);
 
        if (codeInfo.isActivated === null) {
          // 激活码未使用：更新isActivated字段和activationTime字段
          activationCodeCollection
            .doc(codeInfo._id)
            .update({
              data: {
                isActivated: true,
                activationTime: formattedTime
              }
            })
            .then(() => {
              console.log('激活状态更新成功');
              // 更新成功后跳转到支付成功页面，并传递激活码
              wx.navigateTo({ 
                url: `/pages/payment-success/payment-success?activationCode=${encodeURIComponent(activationCode)}`
              });
            })
            .catch(err => {
              wx.hideLoading();
              wx.showToast({ 
                title: '更新激活状态失败，请重试',
                icon: 'none',
                duration: 2000
              });
              console.error('更新激活状态失败：', err);
              // 添加更详细的错误信息输出
              console.error('错误代码:', err.errCode);
              console.error('错误信息:', err.errMsg);
            });
        } else if (codeInfo.isActivated === true && codeInfo.isSubmitted === null) {
          // 激活码已使用未激活：跳转到表格/form页面，传递激活码参数
          wx.navigateTo({ 
            url: `/pages/form/form?activationCode=${encodeURIComponent(activationCode)}`
          });
        } else if (codeInfo.isActivated === true && codeInfo.isSubmitted === true) {
          // 激活码已使用已激活：跳转到结果/result页面并且携带apiResponse字段数据
          wx.navigateTo({ 
            url: `/pages/result/result?data=${encodeURIComponent(JSON.stringify({ apiResponse: codeInfo.apiResponse }))}` 
          });
        }
      })
      .catch(err => {
        wx.hideLoading(); 
        wx.showToast({ 
          title: '网络异常，请重试',
          icon: 'none',
          duration: 2000
        });
        console.error(' 激活码验证失败：', err);
      });
  }
});