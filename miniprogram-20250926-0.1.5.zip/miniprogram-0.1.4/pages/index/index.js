// index.js
/**
 * 首页页面逻辑文件 (index.js)
 * 
 * 本文件是应用的入口页面逻辑控制器，主要负责以下功能：
 * 1. 定义页面的行为和交互逻辑
 * 2. 提供导航功能，引导用户进入天赋激活流程
 * 3. 处理页面跳转的成功和失败情况
 * 
 * 页面结构由对应的index.wxml定义，样式由index.wxss定义
 */

// 微信小程序页面注册函数，用于创建页面实例
Page({
  /**
   * 跳转到激活码页面
   * 
   * 功能：当用户点击"开启天赋之旅"按钮时触发，导航到天赋激活页面
   * 用途：作为应用的主要入口点，连接首页和天赋探索流程
   * 
   * 实现细节：
   * - 使用wx.navigateTo API进行页面跳转，保留当前页面在栈中
   * - 跳转到/pages/activation/activation页面，用户需要在此输入激活码
   * - 包含成功和失败的回调处理，确保用户体验的完整性
   * 
   * 异常处理：
   * - 失败时在控制台记录错误信息，便于调试
   * - 向用户显示友好的错误提示信息
   */
  navigateToActivation() {
    wx.navigateTo({
      url: '/pages/activation/activation', // 使用绝对路径确保跳转的可靠性
      success: () => {
        // 跳转成功后的回调函数
        console.log('跳转至激活页面成功');
      },
      fail: (err) => {
        // 跳转失败时的错误处理
        console.error('跳转至激活页面失败:', err);
        // 显示错误提示，提升用户体验
        wx.showToast({
          title: '跳转失败，请稍后重试',
          icon: 'none' // 仅显示文本提示，不显示图标
        });
      }
    });
  },

  // 分享给朋友
  onShareAppMessage: function() {
    return {
      title: '探索你的天赋潜能，开启专属成长之旅！',
      path: '/pages/index/index',
      imageUrl: '', // 可以添加分享图片路径
      success: function(res) {
        console.log('分享成功', res);
      },
      fail: function(res) {
        console.log('分享失败', res);
      }
    };
  },

  // 分享到朋友圈
  onShareTimeline: function() {
    return {
      title: '每个人都有独特的天赋，快来发现属于你的潜能吧！', 
      query: 'share=true',
      path: '/pages/index/index',
      imageUrl: '' // 可以添加分享图片路径
    };
  }
});
