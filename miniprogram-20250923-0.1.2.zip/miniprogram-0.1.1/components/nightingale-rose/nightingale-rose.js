Component({
  properties: {
    data: {
      type: Array,
      value: []
    },
    width: {
      type: Number,
      value: 0.8  // 相对数值：0.8表示父容器宽度的80%
    },
    height: {
      type: Number,
      value: 0.8  // 相对数值：0.8表示父容器高度的80%
    }
  },

  data: {
    roseData: [],
    centerX: 0.35,  // 相对位置：0.35表示画布宽度的35%
    centerY: 0.7,  // 相对位置：0.5表示画布高度的50%（居中）
    maxRadius: 1, // 相对半径
    canvasWidth: 0, // 实际画布宽度
    canvasHeight: 0  // 实际画布高度
  },

  lifetimes: {
    attached() {
      this.calculateCanvasSize();
      // 延迟初始化，确保数据已经传入
      setTimeout(() => {
        this.initRoseChart();
      }, 100);
    }
  },

  observers: {
    'data': function(newData) {
      try {
        if (newData && newData.length > 0) {
          this.initRoseChart();
        }
      } catch (error) {
        console.error('玫瑰图数据更新失败:', error);
      }
    }
  },

  methods: {
    calculateCanvasSize: function() {
      // 获取系统信息
      var systemInfo = wx.getSystemInfoSync();
      var screenWidth = systemInfo.screenWidth;
      var screenHeight = systemInfo.screenHeight;
      
      // 计算实际画布尺寸（基于屏幕尺寸的相对值）
      var canvasWidth = Math.floor(screenWidth * this.data.width);
      var canvasHeight = Math.floor(screenHeight * this.data.height);
      
      // 确保最小尺寸
      canvasWidth = Math.max(canvasWidth, 300);
      canvasHeight = Math.max(canvasHeight, 300);
      
      this.setData({
        canvasWidth: canvasWidth,
        canvasHeight: canvasHeight
      });
      
      console.log('画布尺寸计算:', {
        screenWidth: screenWidth,
        screenHeight: screenHeight,
        widthRatio: this.data.width,
        heightRatio: this.data.height,
        canvasWidth: canvasWidth,
        canvasHeight: canvasHeight
      });
    },
    
    initRoseChart: function() {
      console.log('初始化玫瑰图，数据:', this.data.data);
      if (!this.data.data || this.data.data.length === 0) {
        console.log('没有数据，跳过初始化');
        return;
      }
      
      // 确保画布尺寸已计算
      if (this.data.canvasWidth === 0 || this.data.canvasHeight === 0) {
        this.calculateCanvasSize();
      }
      
      var roseData = this.processData();
      console.log('处理后的玫瑰图数据:', roseData);
      if (roseData && roseData.length > 0) {
        this.setData({ roseData: roseData });
        this.drawRoseChart();
      }
    },

    processData: function() {
      var data = this.data.data;
      if (!data || data.length === 0) {
        return [];
      }
      
      var maxRadius = Math.min(this.data.canvasWidth, this.data.canvasHeight) * this.data.maxRadius;
      var maxValue = Math.max.apply(null, data.map(function(item) { return item.value; }));
      
      // 按数值排序，确保最大的在第一位
      var sortedData = data.slice().sort(function(a, b) { return b.value - a.value; });
      
      return sortedData.map(function(item, index) {
        // 让最大的扇形从顶部开始（-Math.PI/2），顺时针排列
        var angle = -Math.PI / 2 + (index * 2 * Math.PI) / data.length;
        var radius = (item.value / maxValue) * maxRadius;
        var startAngle = angle;
        var endAngle = angle + (2 * Math.PI / data.length);
        
        var result = {};
        for (var key in item) {
          if (item.hasOwnProperty(key)) {
            result[key] = item[key];
          }
        }
        result.angle = angle;
        result.startAngle = startAngle;
        result.endAngle = endAngle;
        result.radius = radius;
        result.x = (this.data.centerX * this.data.canvasWidth) + Math.cos(angle) * (radius / 2);
        result.y = (this.data.centerY * this.data.canvasHeight) + Math.sin(angle) * (radius / 2);
        // 白粉主色，深灰复色配色方案
        var colors = ['#FFF2DF', '#FFF2DF', '#FFF2DF', '#363636']; // 三白粉一深灰，白粉为主色
        result.color = colors[index % colors.length];
        
        return result;
      }.bind(this));
    },

    drawRoseChart: function() {
      console.log('开始绘制玫瑰图，画布尺寸:', this.data.canvasWidth, 'x', this.data.canvasHeight);
      var ctx = wx.createCanvasContext('roseCanvas', this);
      // 计算实际像素坐标
      var centerX = this.data.centerX * this.data.canvasWidth;
      var centerY = this.data.centerY * this.data.canvasHeight;
      var maxRadius = Math.min(this.data.canvasWidth, this.data.canvasHeight) * this.data.maxRadius;
      console.log('中心点坐标:', centerX, centerY, '最大半径:', maxRadius);
      
      // 清空画布
      ctx.clearRect(0, 0, this.data.canvasWidth, this.data.canvasHeight);
      
      // 绘制中心点
      ctx.beginPath();
      ctx.arc(centerX, centerY, 8, 0, 2 * Math.PI);
      ctx.setFillStyle('#FFFFFF');
      ctx.fill();
      
      // 绘制玫瑰图扇形
      var that = this;
      this.data.roseData.forEach(function(item) {
        that.drawRoseSegment(ctx, item);
      });
      
      // 绘制标签
      this.drawLabels(ctx);
      
      ctx.draw();
    },

    drawRoseSegment: function(ctx, item) {
      // 计算实际像素坐标
      var centerX = this.data.centerX * this.data.canvasWidth;
      var centerY = this.data.centerY * this.data.canvasHeight;
      
      // 绘制扇形
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.arc(centerX, centerY, item.radius, item.startAngle, item.endAngle);
      ctx.closePath();
      
      ctx.setFillStyle(item.color);
      ctx.fill();
      
      // 无边框设计，实现无缝连接
    },

    drawLabels: function(ctx) {
      // 安全检查，确保数据存在
      if (!this.data.roseData || this.data.roseData.length === 0) {
        return;
      }
      
      var that = this;
      // 计算实际像素坐标
      var centerX = this.data.centerX * this.data.canvasWidth;
      var centerY = this.data.centerY * this.data.canvasHeight;
      var maxRadius = Math.min(this.data.canvasWidth, this.data.canvasHeight) * this.data.maxRadius;
      
      // 标注所有天赋
      this.data.roseData.forEach(function(item, index) {
        // 计算扇形1/2角度位置，让文字位于扇形的中间角度
        var halfAngle = item.startAngle + (item.endAngle - item.startAngle) / 2;
        
        // 根据角度判断左半边还是右半边，使用不同的labelRadius
        var labelRadius;
        if (halfAngle > Math.PI / 2 && halfAngle < 3 * Math.PI / 2) {
          // 左半边，使用较小的半径
          labelRadius = item.radius * 0.4;
        } else {
          // 右半边，使用较大的半径
          labelRadius = item.radius * 0.8;
        }
        
        // 项目管理位置（顶部位置）的文字按照右边的0.8来排布
        // 顶部位置角度范围：-Math.PI/2 到 Math.PI/2 之间，且接近 -Math.PI/2
        if (halfAngle > -Math.PI / 2 - Math.PI / 8 && halfAngle < -Math.PI / 2 + Math.PI / 8) {
          // 项目管理位置，使用0.8的半径
          labelRadius = item.radius * 0.8;
        }
        
        var labelX = centerX + Math.cos(halfAngle) * labelRadius;
        var labelY = centerY + Math.sin(halfAngle) * labelRadius;
        
        // 绘制天赋名称，字体大小与扇形区域大小成正比
        var maxValue = Math.max.apply(null, that.data.roseData.map(function(item) { return item.value; }));
        var minValue = Math.min.apply(null, that.data.roseData.map(function(item) { return item.value; }));
        
        // 计算字体大小，确保有明显的比例差异
        var fontSize;
        if (maxValue === minValue) {
          fontSize = 16; // 如果所有值相同，使用中等大小
        } else {
          // 字体大小范围：10-22px，比例更明显
          var ratio = (item.value - minValue) / (maxValue - minValue);
          fontSize = Math.max(10, Math.min(22, 10 + ratio * 12));
        }
        
        // 左边字体等比例缩小，避免超出扇形
        if (halfAngle > Math.PI / 2 && halfAngle < 3 * Math.PI / 2) {
          // 左半边，字体缩小到原来的70%
          fontSize = fontSize * 0.7;
        }
        
        // 设置字体大小（微信小程序Canvas不支持setFont方法）
        ctx.setFontSize(fontSize);
        
        // 使用爱马仕橙作为文字颜色
        ctx.setFillStyle('#FF8A00');
        
        // 计算文字角度，让文字沿着径向排布
        var textAngle = halfAngle; // 让文字沿着扇形1/2角度的径向方向排列
        
        // 根据角度调整文字对齐方式，优化径向排列效果
        if (textAngle > Math.PI / 2 && textAngle < 3 * Math.PI / 2) {
          // 左半圆，文字左对齐
          ctx.setTextAlign('left');
          ctx.setTextBaseline('middle');
        } else {
          // 右半圆，文字右对齐
          ctx.setTextAlign('right');
          ctx.setTextBaseline('middle');
        }
        
        // 保存当前状态
        ctx.save();
        
        // 移动到文字位置并旋转
        ctx.translate(labelX, labelY);
        ctx.rotate(textAngle);
        
        // 绘制天赋名称和占比在一行（无阴影效果）
        var displayText = item.talent;
        if (item.percentage) {
          displayText = item.talent + ' ' + item.percentage + '%';
        }
        ctx.fillText(displayText, 0, 0);
        
        // 恢复状态
        ctx.restore();
      });
    }
  }
});