const app = getApp();
 
app.cloud  = wx.cloud.init({ 
  env: 'cloud1-3g13pog48601829d', // 替换为你自己的环境ID
  traceUser: true
});
 
const db = wx.cloud.database(); 
const activationCodeCollection = db.collection('activation_codes'); 
 
module.exports  = {
  db,
  activationCodeCollection
};