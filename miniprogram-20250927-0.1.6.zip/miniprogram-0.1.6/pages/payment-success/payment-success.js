// payment-success.js 
Page({
  data: {
    progress: 0, // 进度条百分比
    timer: null,  // 计时器
    activationCode: '' // 存储从激活页面传递过来的激活码
  },
 
  onLoad(options) {
    // 获取从激活页面传递过来的激活码
    if (options.activationCode) {
      this.setData({
        activationCode: options.activationCode
      });
    }
    // 开始倒计时
    this.startCountdown(); 
  },
 
  onUnload() {
    // 页面卸载时清除计时器
    if (this.data.timer)  {
      clearInterval(this.data.timer); 
    }
  },
 
  // 开始倒计时 
  startCountdown() {
    let progress = 0;
    const timer = setInterval(() => {
      progress += 1;
      this.setData({  progress });
      
      if (progress >= 100) {
        clearInterval(timer);
        this.navigateToForm(); 
      }
    }, 10);
    
    this.setData({  timer });
  },
 
  // 跳转到表单页面，并传递激活码
  navigateToForm() {
    wx.redirectTo({ 
      url: `/pages/form/form?activationCode=${encodeURIComponent(this.data.activationCode)}`
    });
  }
});