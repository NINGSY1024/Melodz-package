const TEST_SAMPLES = [
  "父辈都是小学初中学历，我是家族第一个名校理工科博士",
  "博士毕业后找到了起薪大几十万的工作",
  "对商业一窍不通，做过微信公众号开发，网站开发，编程教学，都失败了，但因为热爱，坚持了2年，最终做天赋解读副业月入1.5w",
  "因为一路读书，意识到自己只懂技术，不懂销售，于是克服卖货羞耻，去线下吆喝摆地摊，练习销售",
  "发现线下销售效率太低，于是转变策略，选择线上营销，最后成功卖出商品1700多份",
  "因为找到了自己的天赋，并且知道怎么找，于是在xhs上开创了天赋解读赛道，并在1.5年内拥有了1.8w粉丝，成为赛道头部",
  "因为做天赋咨询业务人力效率太低，于是组织2个朋友一起做天赋解读小程序，用了1个月做成了，第一天就卖出去85个小程序激活码",
  "非常擅长用故事来讲人生道理，写了70多篇小红书帖子，有十几篇千赞爆款",
  "我曾经举办过一场小型的脱口秀，结束2个星期，半年，一年，两年后，仍被朋友提及，并表示愿意付费，还建议我走职业路线",
  "我很擅长讲故事和教学，讲如何找天赋那期课，来听的有18人，有6人听完为我付费，1h赚了1800元"
];

// 引入云开发数据库集合 
const { activationCodeCollection } = require('../../utils/cloud');

Page({
  data: {
    highlights: ['', '', '', '', ''],
    activationCode: '', // 存储从激活页面传递过来的激活码
    age: '30', // 默认年龄30岁（改为字符串形式用于文本输入）
    careerStatusOptions: ['小学生', '初中生', '高中生', '本科生', '研究生', '进入职场1年', '进入职场1-3年', '进入职场3-5年', '进入职场5-8年', '进入职场8年以上'],
    careerStatusIndex: -1, // 默认未选择
    educationOptions: ['初中及以下', '高中/中专', '大专', '本科', '硕士研究生', '博士研究生'], // 学历选项
    educationIndex: -1, // 默认未选择学历
    careerConfusion: '' // 职业困惑
  },

  // 页面加载时获取激活码参数
  onLoad(options) {
    // 从页面参数中获取激活码
    if (options.activationCode) {
      this.setData({
        activationCode: options.activationCode
      });
    }
  },
 

 
  // 高光时刻输入事件
  onHighlightInput(e) {
    const index = e.currentTarget.dataset.index; 
    const newHighlights = this.data.highlights.slice(); 
    newHighlights[index] = e.detail.value; 
    this.setData({  highlights: newHighlights });
  },

  // 年龄输入事件
  onAgeInput(e) {
    const ageValue = e.detail.value;
    // 只允许输入数字
    if (/^\d*$/.test(ageValue)) {
      this.setData({
        age: ageValue
      });
    }
  },
  
  // 学历变化事件
  onEducationChange(e) {
    this.setData({
      educationIndex: e.detail.value
    });
  },

  // 职业状态变化事件
  onCareerStatusChange(e) {
    this.setData({
      careerStatusIndex: e.detail.value
    });
  },

  // 职业困惑输入事件
  onCareerConfusionInput(e) {
    this.setData({
      careerConfusion: e.detail.value
    });
  },
 
  // 加载测试样例（加载全部样例）
  loadSample() {
    this.setData({  highlights: TEST_SAMPLES.slice() });
  },
 
  // 添加更多高光时刻输入框，最多10个
  addMoreHighlight() {
    if (this.data.highlights.length >= 10) {
      wx.showToast({
        title: '最多只能添加10个高光时刻',
        icon: 'none'
      });
      return;
    }
    const newHighlights = this.data.highlights.slice();
    newHighlights.push('');
    this.setData({
      highlights: newHighlights
    });
  },
 
  // 临时存为草稿
  saveAsDraft() {
    const { highlights, activationCode, age, careerStatusIndex, careerStatusOptions, educationIndex, educationOptions, careerConfusion } = this.data; 
    
    // 获取职业状态和学历的值
    const careerStatus = careerStatusIndex >= 0 ? careerStatusOptions[careerStatusIndex] : '';
    const education = educationIndex >= 0 ? educationOptions[educationIndex] : ''; 
    
    const filledHighlights = highlights.filter(function(h) { return h.trim(); }); 
    
    // 检查是否有数据
    if (filledHighlights.length === 0) {
      wx.showToast({
        title: '请输入高光时刻',
        icon: 'none'
      });
      return;
    }

    // 显示加载动画
    wx.showLoading({
      title: '保存中...',
      mask: true
    });

    // 格式化当前时间为YYYY-MM-DD HH:mm:ss格式
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const formattedTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

    // 查询并更新数据库
    activationCodeCollection
      .where({
        activationCode: activationCode
      })
      .get()
      .then(res => {
        if (res.data.length > 0) {
          const codeInfo = res.data[0];
          
          // 更新数据库字段
          return activationCodeCollection
            .doc(codeInfo._id)
            .update({
              data: {
                isSaved: true, // 设置为已保存
                submittedContent: {
                    highlights: highlights, // 高光时刻内容
                    age: age, // 年龄
                    careerStatus: careerStatus, // 职业状态
                    education: education, // 学历
                    careerConfusion: careerConfusion // 职业困惑
                  },
                savedTime: formattedTime // 保存时间
              }
            });
        } else {
          throw new Error('未找到对应的激活码记录');
        }
      })
      .then(() => {
        wx.hideLoading();
        wx.showToast({
          title: '草稿保存成功',
          icon: 'success'
        });
        console.log('草稿保存成功');
      })
      .catch(err => {
        wx.hideLoading();
        wx.showToast({
          title: '保存失败，请重试',
          icon: 'none',
          duration: 2000
        });
        console.error('保存草稿失败：', err);
        console.error('错误代码:', err.errCode);
        console.error('错误信息:', err.errMsg);
      });
  },

  // 提取上次保存
  restoreLastDraft() {
    const { activationCode } = this.data;

    // 显示加载动画
    wx.showLoading({
      title: '加载中...',
      mask: true
    });

    // 查询数据库
    activationCodeCollection
      .where({
        activationCode: activationCode
      })
      .get()
      .then(res => {
        if (res.data.length > 0) {
          const codeInfo = res.data[0];
          
          // 检查是否已保存
          if (codeInfo.isSaved !== true) {
            wx.hideLoading();
            wx.showToast({
              title: '请先保存高光时刻',
              icon: 'none'
            });
            return;
          }
          
          // 恢复数据
            // 兼容旧版本数据结构
            const submittedContent = codeInfo.submittedContent || {};
            const highlights = Array.isArray(submittedContent) ? submittedContent : (submittedContent.highlights || ['', '', '', '', '']);
            
            this.setData({
              highlights: highlights,
              age: (submittedContent.age || codeInfo.age || 30).toString(), // 确保是字符串格式
              careerStatusIndex: submittedContent.careerStatus ? this.data.careerStatusOptions.indexOf(submittedContent.careerStatus) : (codeInfo.careerStatus ? this.data.careerStatusOptions.indexOf(codeInfo.careerStatus) : -1),
              educationIndex: submittedContent.education ? this.data.educationOptions.indexOf(submittedContent.education) : (codeInfo.education ? this.data.educationOptions.indexOf(codeInfo.education) : -1),
              careerConfusion: submittedContent.careerConfusion || codeInfo.careerConfusion || ''
            });
          
          wx.hideLoading();
          wx.showToast({
            title: '草稿恢复成功',
            icon: 'success'
          });
          console.log('草稿恢复成功');
        } else {
          wx.hideLoading();
          wx.showToast({
            title: '未找到对应的激活码记录',
            icon: 'none'
          });
        }
      })
      .catch(err => {
        wx.hideLoading();
        wx.showToast({
          title: '加载失败，请重试',
          icon: 'none',
          duration: 2000
        });
        console.error('恢复草稿失败：', err);
        console.error('错误代码:', err.errCode);
        console.error('错误信息:', err.errMsg);
      });
  },

  // 提交表单并跳转
  submitForm() {
    const { highlights, activationCode, age, careerStatusIndex, careerStatusOptions, educationIndex, educationOptions, careerConfusion } = this.data;
    
    // 检查是否为特殊情况：年龄为99（支持各种可能的输入格式）
    // 转换为字符串后去除空格，再与'99'比较
    const ageStr = String(age).trim();
    if (ageStr === '99') {
      // 显示加载动画
      wx.showLoading({
        title: '处理中...',
        mask: true
      });

      // 格式化当前时间为YYYY-MM-DD HH:mm:ss格式
      const now = new Date();
      const year = now.getFullYear();
      const month = String(now.getMonth() + 1).padStart(2, '0');
      const day = String(now.getDate()).padStart(2, '0');
      const hours = String(now.getHours()).padStart(2, '0');
      const minutes = String(now.getMinutes()).padStart(2, '0');
      const seconds = String(now.getSeconds()).padStart(2, '0');
      const formattedTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

      // 查询并更新数据库
      activationCodeCollection
        .where({
          activationCode: activationCode
        })
        .get()
        .then(res => {
          if (res.data.length > 0) {
            const codeInfo = res.data[0];
            
            // 检查是否已提交
            if (codeInfo.isSubmitted === true) {
              wx.hideLoading();
              wx.showToast({
                title: '该激活码已被关闭',
                icon: 'none',
                duration: 2000
              });
              return Promise.reject('重复提交');
            }
            
            // 更新数据库字段
            return activationCodeCollection
              .doc(codeInfo._id)
              .update({
                data: {
                  isSubmitted: true, // 设置为已提交
                  submittedTime: formattedTime // 设置提交时间
                }
              });
          } else {
            throw new Error('未找到对应的激活码记录');
          }
        })
        .then(() => {
          wx.hideLoading();
          wx.showToast({
            title: '该激活码关闭成功',
            icon: 'success',
            duration: 2000
          });
        })
        .catch(err => {
          wx.hideLoading();
          wx.showToast({
            title: '操作失败，请重试',
            icon: 'none',
            duration: 2000
          });
          console.error('关闭激活码失败：', err);
        });
      return;
    }
    
    // 验证年龄输入
    const ageNum = parseInt(age);
    if (!age || isNaN(ageNum) || ageNum < 12 || ageNum > 60) {
      wx.showToast({
        title: '请输入12-60之间的阿拉伯数字作为年龄',
        icon: 'none'
      });
      return;
    }
    
    // 获取职业状态和学历的值
    const careerStatus = careerStatusIndex >= 0 ? careerStatusOptions[careerStatusIndex] : '';
    const education = educationIndex >= 0 ? educationOptions[educationIndex] : '';

    const filledHighlights = highlights.filter(function(h) { return h.trim(); }); 

    // 至少填写5个高光时刻，最多10个
    if (filledHighlights.length < 5) {
      wx.showToast({  title: '请至少填写五个高光时刻', icon: 'none' });
      return;
    }
    if (filledHighlights.length > 10) {
      wx.showToast({  title: '高光时刻不能超过10个', icon: 'none' });
      return;
    }

    // 表单验证通过后，显示确认弹窗
    wx.showModal({
      title: '提交确认',
      content: '只有一次提交机会，请认真选择哦💗',
      confirmText: '直接提交',
      cancelText: '继续填写',
      success: (res) => {
        if (res.confirm) {
          // 用户点击直接提交，继续执行提交逻辑
          this.submitConfirmed(highlights, activationCode, age, careerStatus, education, careerConfusion);
        } else if (res.cancel) {
          // 用户点击继续填写，关闭弹窗，不执行任何操作
          console.log('用户选择继续填写');
        }
      }
    });
  },
  
  // 用户确认提交后的处理函数
  submitConfirmed(highlights, activationCode, age, careerStatus, education, careerConfusion) {
    // 显示加载动画
    wx.showLoading({
      title: '提交中...',
      mask: true
    });

    // 格式化当前时间为YYYY-MM-DD HH:mm:ss格式
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const formattedTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

    // 查询并更新数据库
    activationCodeCollection
      .where({
        activationCode: activationCode
      })
      .get()
      .then(res => {
        if (res.data.length > 0) {
          const codeInfo = res.data[0];
          
          // 检查是否已提交
          if (codeInfo.isSubmitted === true) {
            wx.hideLoading();
            wx.showToast({
              title: '请勿重复提交',
              icon: 'none',
              duration: 2000
            });
            return Promise.reject('重复提交');
          }
          
          // 如果isSubmitted为null或其他值，继续原有逻辑
          // 更新数据库字段
          return activationCodeCollection
            .doc(codeInfo._id)
            .update({
              data: {
                isSubmitted: true, // 设置为已提交
                submittedContent: {
                    highlights: highlights, // 高光时刻内容
                    age: age, // 年龄
                    careerStatus: careerStatus, // 职业状态
                    education: education, // 学历
                    careerConfusion: careerConfusion // 职业困惑
                  },
                submittedTime: formattedTime // 设置提交时间
              }
            });
        } else {
          throw new Error('未找到对应的激活码记录');
        }
      })
      .then(() => {
        wx.hideLoading();
        console.log('数据库更新成功');
        
        // 更新成功后跳转到结果页面
        wx.navigateTo({ 
          url: '/pages/result/result?'+ 
               'submittedContent=' + encodeURIComponent(JSON.stringify({
                 highlights: highlights,
                 age: age,
                 careerStatus: careerStatus,
                 education: education,
                 careerConfusion: careerConfusion
               })) +
               '&activationCode=' + encodeURIComponent(activationCode) 
        });
      })
      .catch(err => {
        wx.hideLoading();
        wx.showToast({
          title: '提交失败，请重试',
          icon: 'none',
          duration: 2000
        });
        console.error('提交表单失败：', err);
        console.error('错误代码:', err.errCode);
        console.error('错误信息:', err.errMsg);
      });
  },

  // 分享给朋友
  onShareAppMessage: function() {
    return {
      title: '填写你的高光时刻，发现隐藏天赋！',
      path: '/pages/index/index',
      imageUrl: '', // 可以添加分享图片路径
      success: function(res) {
        console.log('分享成功', res);
      },
      fail: function(res) {
        console.log('分享失败', res);
      }
    };
  },

  // 分享到朋友圈
  onShareTimeline: function() {
    return {
      title: '回顾你的高光时刻，发现真实的自己和潜在天赋', 
      query: 'share=true',
      path: '/pages/index/index',
      imageUrl: '' // 可以添加分享图片路径
    };
  }
});