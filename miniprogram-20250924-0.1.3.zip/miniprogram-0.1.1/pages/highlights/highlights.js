// pages/highlights/highlights.js
const api = require('../../utils/api.js');

Page({
  data: {
    activeTab: 'talents',
    analysisData: null,
    talentCards: [],
    wordCloudData: [],
    celebrities: [],
    aceTalents: [],
    loading: true,
    userId: '',
    highlights: []
  },

  onLoad(options) {
    const userId = wx.getStorageSync('userId') || 'user_' + Date.now();
    const highlights = wx.getStorageSync('highlights') || [];
    
    this.setData({
      userId,
      highlights
    });

    this.loadAnalysisData();
  },

  async loadAnalysisData() {
    try {
      this.setData({ loading: true });
      
      const analysisResult = await api.analyzeHighlights(this.data.highlights, this.data.userId);
      const stats = await api.getTalentStatistics(analysisResult);
      
      this.setData({
        analysisData: analysisResult,
        talentCards: this.generateTalentCards(stats.topThreeTalents),
        wordCloudData: stats.wordCloud,
        celebrities: stats.celebrities,
        aceTalents: this.generateAceTalents(stats.topThreeTalents),
        loading: false
      });
    } catch (error) {
      console.error('加载分析数据失败:', error);
      wx.showToast({
        title: '加载失败，请重试',
        icon: 'none'
      });
      this.setData({ loading: false });
    }
  },

  generateTalentCards(topTalents) {
    if (!topTalents || !Array.isArray(topTalents)) return [];
    return topTalents.map((talent, index) => ({
      id: index + 1,
      name: talent.talent || '未知天赋',
      level: this.getTalentLevel(talent.percentage || 0),
      percentage: talent.percentage || 0,
      description: this.getTalentDescription(talent.talent || '未知天赋'),
      examples: this.getTalentExamples(talent.talent || '未知天赋'),
      color: this.getTalentColor(index)
    }));
  },

  generateAceTalents(topTalents) {
    if (!topTalents || !Array.isArray(topTalents)) return [];
    return topTalents.slice(0, 3).map((talent, index) => ({
      rank: index + 1,
      name: talent.talent || '未知天赋',
      score: talent.percentage || 0,
      category: this.getTalentCategory(talent.talent || '未知天赋'),
      description: this.getAceTalentDescription(talent.talent || '未知天赋'),
      potential: this.getTalentPotential(talent.talent || '未知天赋')
    }));
  },

  getTalentLevel(percentage) {
    if (percentage >= 80) return '卓越';
    if (percentage >= 60) return '优秀';
    if (percentage >= 40) return '良好';
    return '一般';
  },

  getTalentDescription(talentName) {
    const descriptions = {
      '领导力': '能够有效地激励和引导他人，带领团队达成共同目标',
      '创新思维': '善于提出新颖的想法和解决方案，突破传统思维模式',
      '逻辑思维': '具备清晰、理性的思考能力，能够系统地分析问题',
      '沟通能力': '能够有效地表达想法，与不同背景的人建立良好关系',
      '执行力': '能够高效地将计划转化为行动，确保任务按时完成'
    };
    return descriptions[talentName] || '具备该领域的核心能力';
  },

  getTalentExamples(talentName) {
    const examples = {
      '领导力': ['组织团队活动', '带领项目成功', '解决团队冲突'],
      '创新思维': ['提出创新方案', '改进工作流程', '开发新产品'],
      '逻辑思维': ['解决复杂问题', '制定详细计划', '分析数据趋势'],
      '沟通能力': ['成功谈判合作', '协调多方关系', '公开演讲'],
      '执行力': ['按时完成项目', '高效处理任务', '达成目标指标']
    };
    return examples[talentName] || ['相关实践经历'];
  },

  getTalentColor(index) {
    const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7'];
    return colors[index % colors.length];
  },

  getTalentCategory(talentName) {
    const categories = {
      '领导力': '人际交往',
      '创新思维': '创造能力',
      '逻辑思维': '认知能力',
      '沟通能力': '人际交往',
      '执行力': '执行能力'
    };
    return categories[talentName] || '综合能力';
  },

  getAceTalentDescription(talentName) {
    const descriptions = {
      '领导力': '你的领导天赋体现在能够凝聚团队力量，激发成员潜能',
      '创新思维': '你的创新能力让你能够突破常规，创造独特价值',
      '逻辑思维': '你的理性思维帮助你做出明智决策，解决复杂问题',
      '沟通能力': '你的沟通优势让你能够建立广泛的人际网络',
      '执行力': '你的高效执行确保想法能够转化为实际成果'
    };
    return descriptions[talentName] || '你的核心优势所在';
  },

  getTalentPotential(talentName) {
    const potentials = {
      '领导力': '未来可发展为高级管理者或企业家',
      '创新思维': '适合从事研发、产品设计或战略规划',
      '逻辑思维': '在金融分析、咨询或技术领域有巨大潜力',
      '沟通能力': '在市场营销、公关或商务谈判方面前景广阔',
      '执行力': '适合项目管理、运营或销售等结果导向岗位'
    };
    return potentials[talentName] || '在相关领域有广阔发展空间';
  },

  switchTab(e) {
    const tab = e.currentTarget.dataset.tab;
    this.setData({ activeTab: tab });
  },

  onShareAppMessage() {
    return {
      title: '我的天赋分析报告',
      path: '/pages/highlights/highlights',
      imageUrl: '' // 可以添加分享图片路径
    };
  },

  onPullDownRefresh() {
    this.loadAnalysisData().finally(() => {
      wx.stopPullDownRefresh();
    });
  }
});