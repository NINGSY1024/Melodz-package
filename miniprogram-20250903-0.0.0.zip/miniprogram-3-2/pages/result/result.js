// result.js  
const { analyzeHighlights } = require('../../utils/api.js');

Page({ 
  data: { 
    isLoading: true,
    activeTab: 'overview',
    userId: '',
    // 输入的高光时刻数组
    highlights: [],
    // 分析结果
    analysis: [], // [{ moment, talents }]
    statistics: { totalTalents: 0, uniqueTalents: 0, topTalents: [] },
    wordCloud: [], // [{ text, value, frequency, x, y }]
    celebrities: [], // 由utils计算，含matchRate
    topThreeAnalysis: { talents: [], relatedHighlights: [] },
    // 概览用计数
    highlightCount: 0,
    talentCount: 0,
    typeCount: 0
  },

  onLoad(options) {
    const userId = options && options.userId ? decodeURIComponent(options.userId) : '';
    let highlightsParam = [];
    if (options && options.highlights) {
      try {
        highlightsParam = JSON.parse(decodeURIComponent(options.highlights));
      } catch (e) {
        highlightsParam = [];
      }
    }

    // 回退到本地存储
    if (!highlightsParam || highlightsParam.length === 0) {
      const formData = wx.getStorageSync('talentFormData') || {};
      if (formData.highlights && typeof formData.highlights === 'string') {
        highlightsParam = formData.highlights.split('\n');
      }
    }

    const filteredHighlights = (highlightsParam || []).filter(h => typeof h === 'string' && h.trim());

    if (!userId) {
      // 默认一个用户ID
      const defaultId = 'user_' + Date.now();
      this.setData({ userId: defaultId });
    } else {
      this.setData({ userId });
    }

    if (filteredHighlights.length === 0) {
    this.setData({  
        isLoading: false,
        highlights: [],
        highlightCount: 0,
        talentCount: 0,
        typeCount: 0
      });
      wx.showToast({ title: '没有找到高光时刻', icon: 'none' });
      return;
    }

    this.setData({ highlights: filteredHighlights });
    this.runAnalysis(filteredHighlights, this.data.userId || userId);
  },

  onTabChange(e) {
    const tab = e.currentTarget.dataset.tab;
    if (!tab) return;
    this.setData({ activeTab: tab });
  },

  // 为词云添加颜色属性
  addWordColors(wordCloud) {
    return wordCloud.map((word, index) => {
      // 根据value值分配颜色 - 暖橙色系
      let color = '#D35400'; // 默认深橙色
      
      if (word.value >= 8) {
        color = '#E67E22'; // 主橙色 - 最高频
      } else if (word.value >= 6) {
        color = '#F39C12'; // 亮橙色 - 高频
      } else if (word.value >= 4) {
        color = '#FF6D00'; // 暖橙色 - 中高频
      } else if (word.value >= 2) {
        color = '#FF8F00'; // 浅橙色 - 中频
      } else {
        color = '#FFB74D'; // 淡橙色 - 低频
      }
      
      return {
        ...word,
        color: color
      };
    });
  },

  // 取5-8个Top天赋，简化版本
  normalizeTopTalents(sortedTopTalents, totalTalents) {
    const limit = Math.min(8, Math.max(5, sortedTopTalents.length));
    const trimmed = sortedTopTalents.slice(0, limit);
    
    return trimmed.map((t, index) => {
      const percentage = trimmed.length > 0 ? 
        Number(((t.count / trimmed[0].count) * 100).toFixed(1)) :
        Number(((t.count / (totalTalents || 1)) * 100).toFixed(1));
      
      // 简化的等级系统
      let gemLevel = '';
      let gemIcon = '';
      let gemColor = '';
      
      if (index === 0) {
        gemLevel = 'SSS';
        gemIcon = '💎';
        gemColor = '#FF6B6B';
      } else if (index === 1) {
        gemLevel = 'SS';
        gemIcon = '💎';
        gemColor = '#4ECDC4';
      } else if (index === 2) {
        gemLevel = 'S';
        gemIcon = '💎';
        gemColor = '#45B7D1';
      } else {
        gemLevel = 'A';
        gemIcon = '⭐';
        gemColor = '#96CEB4';
      }
      
      return {
        ...t,
        percentage,
        gemLevel,
        gemIcon,
        gemColor,
        starCount: Math.min(5, Math.ceil(percentage / 20))
      };
    });
  },

  runAnalysis(highlights, userId) {
    this.setData({ isLoading: true });
    analyzeHighlights(highlights, userId)
      .then(res => {
        // 计算topThree相关高光
        const sortedTopTalents = (res.statistics && res.statistics.frequencyDistribution) ? res.statistics.frequencyDistribution : [];
        const normalizedTopTalents = this.normalizeTopTalents(sortedTopTalents, (res.statistics && res.statistics.totalTalents) || 0);
        const topThreeNames = normalizedTopTalents.slice(0, 3).map(t => t.talent);

        const relatedHighlights = [];
        (res.analysis || []).forEach(item => {
          (topThreeNames || []).forEach(talent => {
            if ((item.talents || []).includes(talent)) {
              relatedHighlights.push({ talent, highlight: item.moment });
            }
          });
        });

        // 为名人补充matchedTalents和圣杯评级
        const celebrities = (res.celebrities || []).map(c => {
          const matchedTalents = (c.talents || []).filter(t => topThreeNames.includes(t));
          const matchScore = matchedTalents.length;
          const maxPossibleMatch = Math.min(topThreeNames.length, c.talents.length);
          const matchRate = maxPossibleMatch > 0 ? Math.round((matchScore / maxPossibleMatch) * 100) : 0;
          
          // 圣杯评级系统：1-3个圣杯
          let cupCount = 1;
          let cupIcon = '🏆';
          let cupColor = '#CD7F32'; // 铜色
          
          if (matchRate >= 80) {
            cupCount = 3;
            cupColor = '#FFD700'; // 金色
          } else if (matchRate >= 50) {
            cupCount = 2;
            cupColor = '#C0C0C0'; // 银色
          }
          
          return {
            ...c,
            matchedTalents,
            matchScore,
            matchRate,
            cupCount,
            cupIcon,
            cupColor
          };
        });

        // 为词云添加颜色
        const coloredWordCloud = this.addWordColors(res.wordCloud || []);

      this.setData({  
          analysis: res.analysis || [],
          statistics: {
            ...(res.statistics || {}),
            topTalents: normalizedTopTalents
          },
          wordCloud: coloredWordCloud,
          celebrities,
          topThreeAnalysis: { talents: topThreeNames, relatedHighlights },
          highlightCount: highlights.length,
          talentCount: (res.statistics && res.statistics.totalTalents) || 0,
          typeCount: (res.statistics && res.statistics.uniqueTalents) || 0,
          isLoading: false
        });
      })
      .catch(() => {
        this.setData({ isLoading: false });
        wx.showToast({ title: '分析失败，请重试', icon: 'none' });
      });
  },

  generateReport() {
    const {
      userId,
      highlights,
      statistics,
      wordCloud,
      celebrities,
      topThreeAnalysis,
      analysis
    } = this.data;

    if (!highlights || highlights.length === 0) {
      wx.showToast({ title: '没有可生成的内容', icon: 'none' });
      return;
    }

    const now = new Date();
    const topTalentsText = (statistics.topTalents || [])
      .map((t, idx) => `${idx + 1}. ${t.talent} - 频次: ${t.count} (${t.percentage || 0}%)`)
      .join('\n');

    const relatedText = (topThreeAnalysis.talents || [])
      .map((talent, idx) => {
        const items = (topThreeAnalysis.relatedHighlights || []).filter(i => i.talent === talent);
        const list = items.map(i => `  • ${i.highlight}`).join('\n');
        return `${idx + 1}. ${talent}\n${list}`;
      })
      .join('\n');

    const celebText = (celebrities || [])
      .slice(0, 3)
      .map((c, idx) => `${idx + 1}. ${c.name}\n   - 描述: ${c.description}\n   - 匹配天赋: ${(c.matchedTalents || []).join(', ')}\n   - 匹配度: ${c.matchRate || 0}%`)
      .join('\n');

    const detailsText = (analysis || [])
      .map((item, idx) => `高光时刻 ${idx + 1}: ${item.moment}\n识别天赋特征: ${(item.talents || []).join(', ')}`)
      .join('\n');

    const reportContent = `天赋特征深度分析报告\n============================\n\n用户ID: ${userId}\n分析时间: ${now.toLocaleString()}\n\n分析概览：\n------------------\n• 总高光时刻数: ${highlights.length}\n• 识别天赋特征总数: ${statistics.totalTalents || 0}\n• 独特天赋类型: ${statistics.uniqueTalents || 0}\n• 最突出天赋特征: ${(statistics.topTalents && statistics.topTalents[0] && statistics.topTalents[0].talent) || '无'} (出现${(statistics.topTalents && statistics.topTalents[0] && statistics.topTalents[0].count) || 0}次)\n\n出现频率前三的天赋特征：\n------------------\n${topTalentsText}\n\n匹配的名人模板：\n------------------\n${celebText}\n\n详细天赋分析：\n------------------\n${detailsText}\n\n============================\n由DeepSeek AI提供专业天赋特征分析`;

    wx.setClipboardData({
      data: reportContent,
      success: () => {
        wx.showToast({ title: '报告已复制到剪贴板', icon: 'success' });
      },
      fail: () => {
        wx.showToast({ title: '复制失败', icon: 'none' });
      }
    });
  }
}); 