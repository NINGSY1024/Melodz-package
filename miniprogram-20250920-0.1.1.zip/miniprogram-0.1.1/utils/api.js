// 小程序版天赋分析API服务
var API_CONFIG = {
  // 使用deepseek API作为后端
  baseUrl: 'https://api.deepseek.com/v1',
  apiKey: 'sk-1f9f63a1363543c8ac2b8cd52400989d',
  model: 'deepseek-chat'
};

// 全局变量：记录已放置的词云位置
var globalPlacedWords = [];

// 天赋特征数据库 - 专为高学历女性设计
var TALENT_DATABASE = [
  // 核心认知能力类
  { id: '1', name: '逻辑思维', category: '认知能力', description: '理性分析问题，构建清晰思维框架' },
  { id: '2', name: '学习能力', category: '认知能力', description: '快速掌握新知识，持续自我提升' },
  { id: '3', name: '批判性思维', category: '认知能力', description: '深度思考，质疑假设，形成独立判断' },
  { id: '4', name: '系统性思维', category: '认知能力', description: '全局视角，理解复杂系统关系' },
  { id: '5', name: '战略思维', category: '认知能力', description: '长远规划，识别关键机会和风险' },
  
  // 专业素养类
  { id: '6', name: '分析能力', category: '专业能力', description: '数据驱动决策，深入问题本质' },
  { id: '7', name: '问题解决', category: '专业能力', description: '结构化思考，系统性解决问题' },
  { id: '8', name: '持续改进', category: '专业能力', description: '追求卓越，不断优化流程和方法' },
  { id: '9', name: '质量意识', category: '专业能力', description: '注重细节，追求完美品质' },
  { id: '10', name: '风险控制', category: '专业能力', description: '预见风险，制定防范措施' },
  
  // 人际交往类
  { id: '11', name: '沟通能力', category: '人际交往', description: '清晰表达，有效传达复杂信息' },
  { id: '12', name: '领导力', category: '人际交往', description: '激发团队潜能，引领变革创新' },
  { id: '13', name: '团队协作', category: '人际交往', description: '促进合作，协调各方资源' },
  { id: '14', name: '跨文化沟通', category: '人际交往', description: '理解多元文化，建立国际视野' },
  { id: '15', name: '影响力', category: '人际交往', description: '说服他人，推动理念落地' },
  
  // 执行管理类
  { id: '16', name: '执行力', category: '执行管理', description: '高效执行，确保目标达成' },
  { id: '17', name: '项目管理', category: '执行管理', description: '统筹规划，协调资源推进项目' },
  { id: '18', name: '时间管理', category: '执行管理', description: '优先级管理，提高工作效率' },
  { id: '19', name: '资源整合', category: '执行管理', description: '整合内外部资源，创造协同效应' },
  { id: '20', name: '结果导向', category: '执行管理', description: '聚焦目标，以结果衡量成功' },
  
  // 创新创造类
  { id: '21', name: '创新思维', category: '创新创造', description: '突破常规，创造新的解决方案' },
  { id: '22', name: '创造力', category: '创新创造', description: '产生原创想法，推动创新发展' },
  { id: '23', name: '适应性', category: '创新创造', description: '快速适应变化，拥抱不确定性' },
  { id: '24', name: '实验精神', category: '创新创造', description: '勇于尝试，从失败中学习成长' },
  { id: '25', name: '未来洞察', category: '创新创造', description: '预见趋势，把握发展方向' },
  
  // 情感智慧类
  { id: '26', name: '情商', category: '情感智慧', description: '理解情绪，建立和谐人际关系' },
  { id: '27', name: '抗压能力', category: '情感智慧', description: '承受压力，在挑战中保持稳定' },
  { id: '28', name: '自我驱动', category: '情感智慧', description: '内在动机，主动追求目标' },
  { id: '29', name: '成长型思维', category: '情感智慧', description: '拥抱挑战，相信能力可以发展' },
  { id: '30', name: '专注力', category: '情感智慧', description: '深度专注，在复杂环境中保持注意力' }
];

// 30位高学历女性崇拜的海内外名人数据库
var CELEBRITY_DATABASE = [
  // 科技与创新女性领袖
  { 
    name: '董明珠', 
    description: '格力电器董事长', 
    avatar: '👩‍💼',
    talents: ['领导力', '决策能力', '抗压能力'],
    achievements: ['格力电器转型', '中国制造品牌', '女性企业家典范']
  },
  { 
    name: '谢丽尔·桑德伯格', 
    description: 'Facebook前COO', 
    avatar: '👩‍💻',
    talents: ['领导力', '沟通能力', '创新思维'],
    achievements: ['Facebook商业化', '《向前一步》作者', '女性领导力倡导']
  },
  { 
    name: '苏珊·沃西基', 
    description: 'YouTube前CEO', 
    avatar: '👩‍🎬',
    talents: ['创新思维', '学习能力', '执行力'],
    achievements: ['YouTube发展', '谷歌广告业务', '科技女性领袖']
  },
  { 
    name: '李飞飞', 
    description: '斯坦福计算机科学教授', 
    avatar: '🔬',
    talents: ['研究能力', '逻辑思维', '创新思维'],
    achievements: ['ImageNet数据集', '计算机视觉突破', '人工智能伦理']
  },
  { 
    name: '吉尼·罗梅蒂', 
    description: 'IBM前CEO', 
    avatar: '👩‍🔬',
    talents: ['领导力', '学习能力', '决策能力'],
    achievements: ['IBM转型', '技术创新推广', '技术女性领导']
  },

  // 学术与科学研究领域
  { 
    name: '屠呦呦', 
    description: '诺贝尔医学奖获得者', 
    avatar: '🏆',
    talents: ['研究能力', '抗压能力', '学习能力'],
    achievements: ['诺贝尔医学奖', '青蒿素发现', '疟疾治疗突破']
  },
  { 
    name: '玛丽·居里', 
    description: '物理学家、化学家', 
    avatar: '⚗️',
    talents: ['研究能力', '抗压能力', '逻辑思维'],
    achievements: ['两次诺贝尔奖', '放射性研究', '科学女性先驱']
  },
  { 
    name: '简·古道尔', 
    description: '灵长类动物学家', 
    avatar: '🦍',
    talents: ['研究能力', '观察能力', '沟通能力'],
    achievements: ['黑猩猩研究', '环保倡导', '科学传播']
  },
  { 
    name: '罗莎琳·富兰克林', 
    description: 'DNA结构发现者', 
    avatar: '🧬',
    talents: ['研究能力', '逻辑思维', '创新思维'],
    achievements: ['DNA双螺旋结构', 'X射线晶体学', '分子生物学贡献']
  },
  { 
    name: '多萝西·霍奇金', 
    description: '结构化学家', 
    avatar: '🔬',
    talents: ['研究能力', '逻辑思维', '抗压能力'],
    achievements: ['诺贝尔化学奖', 'X射线晶体学', '蛋白质结构研究']
  },

  // 社会影响与公益领域
  { 
    name: '马拉拉·优素福扎伊', 
    description: '诺贝尔和平奖获得者', 
    avatar: '🕊️',
    talents: ['沟通能力', '抗压能力', '领导力'],
    achievements: ['诺贝尔和平奖', '教育权益倡导', '全球青年领袖']
  },
  { 
    name: '米歇尔·奥巴马', 
    description: '前美国第一夫人', 
    avatar: '👑',
    talents: ['沟通能力', '领导力', '情商管理'],
    achievements: ['第一夫人', '教育倡导', '《成为》作者']
  },
  { 
    name: '梅琳达·盖茨', 
    description: '慈善家', 
    avatar: '💝',
    talents: ['组织能力', '沟通能力', '决策能力'],
    achievements: ['盖茨基金会', '全球健康倡导', '女性赋权']
  },
  { 
    name: '奥普拉·温弗瑞', 
    description: '媒体女王', 
    avatar: '🎤',
    talents: ['沟通能力', '情商管理', '领导力'],
    achievements: ['脱口秀女王', '媒体帝国', '慈善事业']
  },
  { 
    name: '杨澜', 
    description: '媒体人、慈善家', 
    avatar: '📺',
    talents: ['沟通能力', '跨文化交流', '组织能力'],
    achievements: ['阳光媒体集团', '国际传播', '慈善事业']
  },

  // 商业与创业领域
  { 
    name: '惠特尼·沃尔夫·赫德', 
    description: 'Bumble创始人', 
    avatar: '💕',
    talents: ['创新思维', '领导力', '沟通能力'],
    achievements: ['Bumble创立', '女性赋权平台', '最年轻女CEO上市']
  },
  { 
    name: '萨拉·布莱克利', 
    description: 'Spanx创始人', 
    avatar: '👗',
    talents: ['创新思维', '抗压能力', '执行力'],
    achievements: ['Spanx品牌', '白手起家', '女性创业典范']
  },
  { 
    name: '梅兰妮·珀金斯', 
    description: 'Canva创始人', 
    avatar: '🎨',
    talents: ['创新思维', '设计能力', '抗压能力'],
    achievements: ['Canva创立', '设计工具普及', '创业坚持']
  },
  { 
    name: '卡特里娜·莱克', 
    description: 'Stitch Fix创始人', 
    avatar: '📊',
    talents: ['数据分析', '创新思维', '学习能力'],
    achievements: ['Stitch Fix', '个性化推荐', '数据驱动商业']
  },
  { 
    name: '英德拉·努伊', 
    description: '百事公司前CEO', 
    avatar: '🥤',
    talents: ['领导力', '决策能力', '学习能力'],
    achievements: ['百事公司转型', '可持续发展', '多元化领导']
  },

  // 文化与艺术领域
  { 
    name: '安娜·温图尔', 
    description: 'Vogue主编', 
    avatar: '👠',
    talents: ['审美能力', '领导力', '沟通能力'],
    achievements: ['Vogue杂志', '时尚产业影响', 'Met Gala策划']
  },
  { 
    name: '碧昂丝', 
    description: '歌手、商业女强人', 
    avatar: '🎵',
    talents: ['艺术表达', '创新思维', '领导力'],
    achievements: ['格莱美奖', '商业帝国', '女性赋权']
  },
  { 
    name: '扎哈·哈迪德', 
    description: '建筑女王', 
    avatar: '🏗️',
    talents: ['创意思维', '设计能力', '抗压能力'],
    achievements: ['普利兹克建筑奖', '解构主义建筑', '突破性设计']
  },
  { 
    name: '朗朗', 
    description: '钢琴家', 
    avatar: '🎹',
    talents: ['艺术表达', '学习能力', '情商管理'],
    achievements: ['国际钢琴家', '音乐教育', '文化交流']
  },

  // 法律与政治领域
  { 
    name: '鲁思·巴德·金斯伯格', 
    description: '美国最高法院大法官', 
    avatar: '⚖️',
    talents: ['逻辑思维', '沟通能力', '抗压能力'],
    achievements: ['最高法院大法官', '性别平等倡导', '法律先驱']
  },
  { 
    name: '希拉里·克林顿', 
    description: '前美国国务卿', 
    avatar: '🏛️',
    talents: ['领导力', '沟通能力', '决策能力'],
    achievements: ['国务卿', '参议员', '女性政治先驱']
  },
  { 
    name: '安吉拉·默克尔', 
    description: '德国前总理', 
    avatar: '🇩🇪',
    talents: ['领导力', '决策能力', '抗压能力'],
    achievements: ['德国总理', '欧盟领导', '危机管理']
  },

  // 医学与健康领域
  { 
    name: '陈薇', 
    description: '军事医学专家', 
    avatar: '💉',
    talents: ['研究能力', '抗压能力', '组织能力'],
    achievements: ['疫苗研发', '生物安全', '军事医学']
  },
  { 
    name: '珍妮弗·道德纳', 
    description: 'CRISPR技术发明者', 
    avatar: '🧬',
    talents: ['研究能力', '创新思维', '逻辑思维'],
    achievements: ['诺贝尔化学奖', 'CRISPR技术', '基因编辑突破']
  },
  { 
    name: '弗朗西斯·阿诺德', 
    description: '化学工程师', 
    avatar: '🧪',
    talents: ['研究能力', '创新思维', '学习能力'],
    achievements: ['诺贝尔化学奖', '酶的定向进化', '绿色化学']
  }
];

/**
 * 分析高光时刻（模拟web版analyze-highlights）
 * @param {Array} highlights - 高光时刻数组
 * @param {string} userId - 用户ID
 * @returns {Promise} - 返回分析结果
 */
function analyzeHighlights(highlights, userId) {
  return new Promise(function(resolve, reject) {
    if (!highlights || highlights.length === 0) {
      reject(new Error('请提供至少一个高光时刻'));
      return;
    }

    var validHighlights = highlights.filter(function(h) { return h.trim() !== ''; });
    
    // 调用真实的DeepSeek API进行基础天赋匹配分析
    console.log('开始调用DeepSeek API进行基础天赋匹配分析...');
    
    // 为每个高光时刻调用DeepSeek API
    var analysisPromises = validHighlights.map(function(highlight, index) {
      return analyzeHighlightWithDeepSeek(highlight, index);
    });
    
    Promise.all(analysisPromises)
      .then(function(analysisResults) {
        try {
          var analysisResult = generateAnalysisFromDeepSeekResults(analysisResults, validHighlights, userId);
        resolve(analysisResult);
      } catch (error) {
        reject(error);
      }
      })
      .catch(function(error) {
        reject(error);
      });
  });
}



/**
 * 基于DeepSeek API结果生成分析数据
 */
function generateAnalysisFromDeepSeekResults(analysisResults, highlights, userId) {
  console.log('基于DeepSeek结果生成分析数据:', analysisResults);
  
  var analysis = analysisResults.map(function(result) {
    return {
      moment: result.moment,
      talents: result.talents
    };
  });

  // 统计所有天赋
  var allTalents = [];
  analysis.forEach(function(item) {
    if (item.talents && Array.isArray(item.talents)) {
      item.talents.forEach(function(talent) {
        allTalents.push(talent);
      });
    }
  });
  
  // 计算天赋频率
  var talentCounts = {};
  allTalents.forEach(function(talent) {
    talentCounts[talent] = (talentCounts[talent] || 0) + 1;
  });

  // 排序并生成统计数据
  var sortedTalents = Object.keys(talentCounts)
    .sort(function(a, b) { return talentCounts[b] - talentCounts[a]; })
    .map(function(talent) {
      return {
        talent: talent,
        count: talentCounts[talent],
        percentage: Number(((talentCounts[talent] / allTalents.length) * 100).toFixed(1))
      };
    });

  // 生成词云数据 - 限制数量避免拥挤
  var maxWords = Math.min(6, sortedTalents.length); // 减少到最多6个词
  
  // 重置全局词云位置记录
  globalPlacedWords = [];
  
  var wordCloudData = sortedTalents.slice(0, maxWords).map(function(item, index) {
    var position = calculateWordPosition(index, item.count, maxWords);
    return {
      text: item.talent,
      value: item.count,
      frequency: Number(((item.count / allTalents.length) * 100).toFixed(1)),
      x: position.x,
      y: position.y,
      importance: index < 2 ? 'core' : index < 4 ? 'important' : 'normal'
    };
  });

  // 获取前3名天赋
  var topThreeTalents = sortedTalents.slice(0, 3);

  // 名人匹配
  var celebrities = matchCelebrities(topThreeTalents.map(function(t) { return t.talent; }));

  // 聚类分析
  var clusters = performClustering(sortedTalents);

  return {
    userId: userId,
    analysis: analysis,
    allTalents: allTalents,
    statistics: {
      totalTalents: allTalents.length,
      uniqueTalents: sortedTalents.length,
      topTalents: topThreeTalents,
      frequencyDistribution: sortedTalents,
      clusters: clusters
    },
    wordCloud: wordCloudData,
    celebrities: celebrities,
    summary: {
      totalMoments: highlights.length,
      totalTalents: allTalents.length,
      uniqueTalents: sortedTalents.length,
      topTalent: topThreeTalents.length > 0 ? topThreeTalents[0].talent : '无',
      topTalentFrequency: topThreeTalents.length > 0 ? topThreeTalents[0].count : 0
    }
  };
}

/**
 * 调用DeepSeek API分析单个高光时刻
 */
function analyzeHighlightWithDeepSeek(highlight, index) {
  return new Promise(function(resolve, reject) {
    var prompt = `你是一位专业的人才分析师，专门为高学历女性分析天赋特征。

请仔细分析以下高光时刻的具体内容，识别出3-5个最突出的天赋特征：

高光时刻：${highlight}

要求：
1. 仔细阅读高光时刻的具体内容，根据描述的场景、行为、结果来选择天赋特征
2. 天赋特征必须来自以下30个选项：
   逻辑思维,学习能力,批判性思维,系统性思维,战略思维,分析能力,问题解决,持续改进,质量意识,风险控制,沟通能力,领导力,团队协作,跨文化沟通,影响力,执行力,项目管理,时间管理,资源整合,结果导向,创新思维,创造力,适应性,实验精神,未来洞察,情商,抗压能力,自我驱动,成长型思维,专注力
3. 根据具体内容选择，不要重复选择相同的天赋

只返回天赋特征名称，用逗号分隔，不要添加任何解释。`;

    wx.request({
      url: 'https://api.deepseek.com/v1/chat/completions',
      method: 'POST',
      header: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer sk-f2e36bf643d74d2dbcb1fdcfb6993ca9'
      },
      data: {
        model: 'deepseek-chat',
        messages: [
          {
            role: 'system',
            content: '你是一位专业的人才分析师，专门为高学历女性分析天赋特征。请严格按照要求返回结果。'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        max_tokens: 100,
        temperature: 0.3
      },
      success: function(res) {
        if (res.statusCode === 200 && res.data && res.data.choices && res.data.choices[0]) {
          var content = res.data.choices[0].message.content.trim();
          var talents = content.split(',').map(function(t) { return t.trim(); }).filter(function(t) { return t.length > 0; });
          
          resolve({
            moment: highlight,
            talents: talents
          });
        } else {
          reject(new Error('DeepSeek API返回数据异常: ' + JSON.stringify(res)));
        }
      },
      fail: function(error) {
        reject(new Error('DeepSeek API调用失败: ' + JSON.stringify(error)));
      }
    });
  });
}

/**
 * 基于wordcloud2.js算法的词云布局
 */
function calculateWordPosition(index, value, totalWords) {
  var containerWidth = 800;
  var containerHeight = 600;
  var centerX = containerWidth / 2;
  var centerY = containerHeight / 2;
  var maxRadius = Math.min(containerWidth, containerHeight) / 2 - 80;
  
  // 根据重要性分配字体大小
  var fontSize = 28 + value * 6;
  var wordWidth = fontSize * 2.5;
  var wordHeight = fontSize * 1.2;
  
  // 第一个词（最高频率）放在正中心
  if (index === 0) {
    return { x: centerX, y: centerY };
  }
  
  // 使用wordcloud2.js的螺旋算法
  var attempts = 0;
  var maxAttempts = 300;
  var step = 0.1;
  var angle = 0;
  var radius = 0;
  
  while (attempts < maxAttempts) {
    // 计算螺旋位置
    angle += step;
    radius += step * 2;
    
    if (radius > maxRadius) {
      radius = maxRadius;
    }
    
    var x = centerX + Math.cos(angle) * radius;
    var y = centerY + Math.sin(angle) * radius;
    
    // 检查边界
    if (x < wordWidth/2 + 40 || x > containerWidth - wordWidth/2 - 40 || 
        y < wordHeight/2 + 40 || y > containerHeight - wordHeight/2 - 40) {
      attempts++;
      continue;
    }
    
    // 检查与已放置词的重叠
    var overlapping = false;
    for (var i = 0; i < index; i++) {
      var existingWord = globalPlacedWords[i];
      if (existingWord) {
        // 使用矩形重叠检测
        if (x < existingWord.x + existingWord.width + 25 &&
            x + wordWidth + 25 > existingWord.x &&
            y < existingWord.y + existingWord.height + 25 &&
            y + wordHeight + 25 > existingWord.y) {
          overlapping = true;
          break;
        }
      }
    }
    
    if (!overlapping) {
      // 记录已放置的词
      globalPlacedWords[index] = {
        x: x,
        y: y,
        width: wordWidth,
        height: wordHeight
      };
      return { x: x, y: y };
    }
    
    attempts++;
  }
  
  // 如果螺旋算法失败，使用网格布局作为备选
  var gridSize = Math.max(wordWidth, wordHeight) + 35;
  var gridCols = Math.ceil(containerWidth / gridSize);
  var gridIndex = index;
  var gridRow = Math.floor(gridIndex / gridCols);
  var gridCol = gridIndex % gridCols;
  
  var x = gridCol * gridSize + gridSize / 2;
  var y = gridRow * gridSize + gridSize / 2;
  
  // 确保在容器范围内
  x = Math.max(wordWidth/2 + 40, Math.min(containerWidth - wordWidth/2 - 40, x));
  y = Math.max(wordHeight/2 + 40, Math.min(containerHeight - wordHeight/2 - 40, y));
  
  globalPlacedWords[index] = {
    x: x,
    y: y,
    width: wordWidth,
    height: wordHeight
  };
  
  return { x: x, y: y };
}



/**
 * 名人匹配逻辑
 */
function matchCelebrities(userTalents) {
  return CELEBRITY_DATABASE.filter(function(celebrity) { 
    return celebrity.talents.some(function(talent) { return userTalents.indexOf(talent) !== -1; });
  }).map(function(celebrity) {
    var celebrityCopy = {};
    for (var key in celebrity) {
      if (celebrity.hasOwnProperty(key)) {
        celebrityCopy[key] = celebrity[key];
      }
    }
    celebrityCopy.matchRate = Math.round((celebrity.talents.filter(function(t) { return userTalents.indexOf(t) !== -1; }).length / celebrity.talents.length) * 100);
    return celebrityCopy;
  }).sort(function(a, b) { return b.matchRate - a.matchRate; }).slice(0, 3);
}

/**
 * 聚类分析 - 基于新的天赋分类体系
 */
function performClustering(talents) {
  var categories = {
    '核心认知能力': ['逻辑思维', '学习能力', '批判性思维', '系统性思维', '战略思维'],
    '专业素养': ['分析能力', '问题解决', '持续改进', '质量意识', '风险控制'],
    '人际交往': ['沟通能力', '领导力', '团队协作', '跨文化沟通', '影响力'],
    '执行管理': ['执行力', '项目管理', '时间管理', '资源整合', '结果导向'],
    '创新创造': ['创新思维', '创造力', '适应性', '实验精神', '未来洞察'],
    '情感智慧': ['情商', '抗压能力', '自我驱动', '成长型思维', '专注力']
  };

  var clusters = [];
  Object.keys(categories).forEach(function(category) {
    var categoryTalents = categories[category];
    var matched = talents.filter(function(t) { return categoryTalents.indexOf(t.talent) !== -1; });
    if (matched.length > 0) {
      clusters.push({
        cluster: category,
        talents: matched.map(function(t) { return t.talent; }),
        frequency: matched.reduce(function(sum, t) { return sum + t.count; }, 0),
        // 新增：天赋组合洞察
        insight: generateCategoryInsight(category, matched),
        // 新增：商业价值建议
        businessValue: generateBusinessValue(category, matched)
      });
    }
  });

  return clusters.sort(function(a, b) { return b.frequency - a.frequency; });
}

/**
 * 生成分类洞察
 */
function generateCategoryInsight(category, talents) {
  var insights = {
    '核心认知能力': '您在认知能力方面表现突出，这为深入分析和战略思考奠定了坚实基础',
    '专业素养': '您的专业素养优秀，能够系统性解决问题并持续优化改进',
    '人际交往': '您具备出色的人际交往能力，善于沟通协调和团队合作',
    '执行管理': '您的执行管理能力强大，能够高效推进项目并达成目标',
    '创新创造': '您拥有丰富的创新创造能力，善于突破常规思维',
    '情感智慧': '您的情商和内在驱动力优秀，能够保持稳定状态并持续成长'
  };
  
  return insights[category] || '该领域的天赋特征为您的职业发展提供了重要支撑';
}

/**
 * 生成商业价值建议
 */
function generateBusinessValue(category, talents) {
  var businessValues = {
    '核心认知能力': '适合担任战略分析师、研究员、咨询顾问等需要深度思考的岗位',
    '专业素养': '适合担任项目经理、质量经理、风险控制专家等专业管理岗位',
    '人际交往': '适合担任团队领导、客户经理、商务拓展等需要人际交往的岗位',
    '执行管理': '适合担任运营总监、产品经理、业务负责人等需要强执行力的岗位',
    '创新创造': '适合担任产品创新、创意总监、创业导师等需要创新思维的岗位',
    '情感智慧': '适合担任人力资源、心理咨询、职业教练等需要情感智慧的岗位'
  };
  
  return businessValues[category] || '建议结合您的具体天赋特征，寻找最适合的职业发展方向';
}

/**
 * 获取天赋统计数据（模拟talent-statistics API）
 */
function getTalentStatistics(analysisData) {
  return new Promise(function(resolve) {
    setTimeout(function() {
      var stats = {
        statistics: analysisData.statistics,
        wordCloud: analysisData.wordCloud,
        topThreeTalents: analysisData.statistics.topTalents,
        clusters: analysisData.statistics.clusters,
        summary: analysisData.summary
      };
      resolve(stats);
    }, 500);
  });
}

/**
 * 生成名人个性化建议
 * @param {Object} celebrity - 名人信息
 * @param {Object} userInfo - 用户信息 {age, careerStatus, careerConfusion}
 * @returns {Promise} - 返回建议内容
 */
function generatePersonalizedAdvice(celebrity, userInfo) {
  return new Promise(function(resolve, reject) {
    // 数据验证
    if (!celebrity || !celebrity.name) {
      reject(new Error('名人信息不完整'));
      return;
    }
    
    if (!userInfo || !userInfo.age) {
      reject(new Error('用户信息不完整'));
      return;
    }
    
    // 确保talents字段存在
    var talents = celebrity.talents || celebrity.matchedTalents || [];
    if (talents.length === 0) {
      talents = ['领导力', '创新思维']; // 默认天赋
    }
    
    console.log('生成建议 - 名人:', celebrity.name, '天赋:', talents, '用户信息:', userInfo);
    
    var prompt = `你是${celebrity.name}，${celebrity.description}。你拥有以下天赋特征：${talents.join('、')}。

现在有一位${userInfo.age}岁的用户向你寻求职业发展建议。她的当前职业状态是：${userInfo.careerStatus || '未填写'}，学历背景是：${userInfo.education || '未填写'}，职业困惑是：${userInfo.careerConfusion || '未填写'}。

请以你的身份和经历，用温暖、专业、富有启发性的语调，为她提供"当前阶段下一步该怎么做"的切实建议。

要求：
1. 以第一人称"我"的口吻，结合你的真实经历和成就
2. 针对她的具体年龄、职业状态和困惑给出建议
3. 提供3-5个具体的、可执行的下一步行动建议
4. 语言要温暖、专业、富有启发性
5. 字数控制在300字以内

请按照以下格式回答：
【我的建议】
[你的建议内容]

【下一步行动】
1. [具体行动1]
2. [具体行动2]
3. [具体行动3]`;

    wx.request({
      url: 'https://api.deepseek.com/v1/chat/completions',
      method: 'POST',
      header: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer sk-f2e36bf643d74d2dbcb1fdcfb6993ca9'
      },
      data: {
        model: 'deepseek-chat',
        messages: [
          {
            role: 'system',
            content: '你是一位成功的企业家/专家，拥有丰富的职业发展经验。请以第一人称的口吻，结合自己的真实经历，为用户提供专业的职业发展建议。'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        max_tokens: 500,
        temperature: 0.8
      },
      success: function(res) {
        console.log('名人建议API响应:', res);
        
        if (res.statusCode === 200 && res.data && res.data.choices && res.data.choices.length > 0) {
          var advice = res.data.choices[0].message.content;
          console.log('名人建议生成成功:', advice);
          
          // 解析建议内容
          var parsedAdvice = parseAdviceContent(advice);
          resolve(parsedAdvice);
        } else {
          console.warn('名人建议API返回数据异常:', res);
          reject(new Error('API返回数据异常: ' + res.statusCode));
        }
      },
      fail: function(error) {
        console.error('名人建议API调用失败:', error);
        reject(error);
      }
    });
  });
}

/**
 * 解析建议内容
 * @param {string} advice - 原始建议文本
 * @returns {Object} - 解析后的建议对象
 */
function parseAdviceContent(advice) {
  try {
    // 提取建议内容
    var adviceMatch = advice.match(/【我的建议】\s*([\s\S]*?)(?=【下一步行动】|$)/);
    var adviceContent = adviceMatch ? adviceMatch[1].trim() : advice;
    
    // 提取下一步行动
    var stepsMatch = advice.match(/【下一步行动】\s*([\s\S]*?)$/);
    var stepsText = stepsMatch ? stepsMatch[1].trim() : '';
    
    // 解析步骤列表
    var nextSteps = [];
    if (stepsText) {
      var stepLines = stepsText.split('\n');
      stepLines.forEach(function(line) {
        line = line.trim();
        if (line && (line.match(/^\d+\./) || line.match(/^[•·-]/))) {
          // 移除序号和符号
          var cleanStep = line.replace(/^\d+\.\s*/, '').replace(/^[•·-]\s*/, '');
          if (cleanStep) {
            nextSteps.push(cleanStep);
          }
        }
      });
    }
    
    return {
      stageAdvice: adviceContent,
      professionalAdvice: adviceContent, // 保持兼容性
      nextSteps: nextSteps
    };
  } catch (error) {
    console.error('解析建议内容失败:', error);
    return {
      stageAdvice: advice,
      professionalAdvice: advice,
      nextSteps: []
    };
  }
}

module.exports = {
  analyzeHighlights,
  analyzeHighlightWithDeepSeek,
  generateAnalysisFromDeepSeekResults,
  getTalentStatistics,
  generatePersonalizedAdvice,
  TALENT_DATABASE,
  CELEBRITY_DATABASE
};