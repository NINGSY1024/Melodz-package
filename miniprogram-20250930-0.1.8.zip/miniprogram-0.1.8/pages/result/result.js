// result.js  

var api = require('../../utils/api.js');
var analyzeHighlights = api.analyzeHighlights;
var generatePersonalizedAdvice = api.generatePersonalizedAdvice;

// 引入云开发数据库集合 
const { activationCodeCollection } = require('../../utils/cloud');

Page({ 
  data: {
    isLoading: true,
    activeTab: 'overview',
    userId: '',
    activationCode: '',
    // 新增isSubmitted数据，默认为null
    isSubmitted: null,
    // 分析状态提示文本
    analysisStatus: '耐心等待10s后，天赋报告完成',
    // 输入的高光时刻数组
    highlights: [],
    // 新增的用户基本信息
    age: 30,
    careerStatus: '',
    careerConfusion: '',
    education: '',
    // 分析结果
    analysis: [], // [{ moment, talents }]
    statistics: { totalTalents: 0, uniqueTalents: 0, topTalents: [] },
    wordCloud: [], // [{ text, value, frequency, x, y }]
    radarData: [], // [{ talent, value, angle, radius }]
    roseData: [], // [{ talent, value, percentage }] 玫瑰图数据
    celebrities: [], // 由utils计算，含matchRate
    topFiveAnalysis: { talents: [], relatedHighlights: [] },
    // 概览用计数
    highlightCount: 0,
    talentCount: 0,
    typeCount: 0,
    // Canvas相关
    canvasWidth: 750, // 画布宽度
    canvasHeight: 3200 // 画布高度（增加以容纳更多内容）
  },

  onLoad(options) {
    var highlightsParam = [];
    var activationCode = options && options.activationCode ? decodeURIComponent(options.activationCode) : '';
    // 获取isSubmitted参数
    var isSubmitted = options && options.isSubmitted !== undefined ? options.isSubmitted === 'true' : null;
    // 获取isLoadSample参数
    var isLoadSample = options && options.isLoadSample !== undefined ? options.isLoadSample === 'true' : false;
    
    // 获取用户基本信息
    var age = 30;
    var careerStatus = '';
    var careerConfusion = '';
    var education = '';
    
    // 优先处理新的submittedContent参数
    if (options && options.submittedContent) {
      try {
        const submittedContent = JSON.parse(decodeURIComponent(options.submittedContent));
        if (submittedContent && typeof submittedContent === 'object') {
          // 如果submittedContent是对象，提取其中的所有信息
          highlightsParam = submittedContent.highlights || [];
          age = submittedContent.age || 30;
          careerStatus = submittedContent.careerStatus || '';
          careerConfusion = submittedContent.careerConfusion || '';
          education = submittedContent.education || '';
        } else if (Array.isArray(submittedContent)) {
          // 兼容旧版本数据结构，如果是数组则直接作为highlights
          highlightsParam = submittedContent;
        }
      } catch (e) {
        console.error('解析submittedContent失败:', e);
        highlightsParam = [];
      }
    } else if (options && options.highlights) {
      // 兼容旧版本的highlights参数
      try {
        highlightsParam = JSON.parse(decodeURIComponent(options.highlights));
      } catch (e) {
        console.error('解析highlights失败:', e);
        highlightsParam = [];
      }
    }

    // 如果是加载样例报告，则使用固定的样例激活码
    var reportActivationCode = activationCode;
    if (isLoadSample) {
      reportActivationCode = 'uygykYjikpLHoRZ4';
    }
    
    // 设置用户ID为激活码和其他基本信息
    this.setData({
      userId: reportActivationCode,
      activationCode: activationCode, // 保留原始激活码
      reportActivationCode: reportActivationCode, // 用于加载报告的激活码
      isSubmitted: isSubmitted,
      isLoadSample: isLoadSample,
      age: age,
      careerStatus: careerStatus,
      careerConfusion: careerConfusion,
      education: education
    });
    
    console.log('接收的激活码:', activationCode);
    console.log('isSubmitted状态:', isSubmitted);
    console.log('用户基本信息:', { age, careerStatus, careerConfusion, education });

    // 如果isSubmitted为true，尝试从数据库读取结果数据
    if (isSubmitted === true && reportActivationCode) {
      this.loadResultDataFromDB();
      return;
    }

    // 原逻辑：如果isSubmitted不为true或没有激活码，按照原逻辑运行
    // 回退到本地存储
    if (!highlightsParam || highlightsParam.length === 0) {
      var formData = wx.getStorageSync('talentFormData') || {};
      if (formData.highlights && typeof formData.highlights === 'string') {
        highlightsParam = formData.highlights.split('\n');
      }
    }

    var filteredHighlights = (highlightsParam || []).filter(function(h) { return typeof h === 'string' && h.trim(); });

    if (filteredHighlights.length === 0) {
      this.setData({  
        isLoading: false,
        highlights: [],
        highlightCount: 0,
        talentCount: 0,
        typeCount: 0
      });
      wx.showToast({ title: '没有找到高光时刻', icon: 'none' });
      return;
    }

    this.setData({ highlights: filteredHighlights });
    this.runAnalysis(filteredHighlights, this.data.userId || activationCode);
  },

  // 从数据库读取结果数据并复现场景
  loadResultDataFromDB() {
    const { reportActivationCode } = this.data;
    
    this.setData({ 
      isLoading: true,
      analysisStatus: '正在加载已保存的天赋报告...'
    });
    
    console.log('开始从数据库加载结果数据，激活码:', reportActivationCode);
    
    activationCodeCollection
      .where({
        activationCode: reportActivationCode,
        isSubmitted: true // 确保是已提交的记录
      })
      .get()
      .then(res => {
        if (res.data.length > 0 && res.data[0].resultData) {
          const codeInfo = res.data[0];
          const resultData = codeInfo.resultData;
          
          console.log('成功加载结果数据:', resultData);
          
          // 复现场景：直接设置所有需要的数据
            // 从submittedContent中提取用户基本信息
            const userInfo = (typeof codeInfo.submittedContent === 'object' && codeInfo.submittedContent !== null) ? 
              codeInfo.submittedContent : { highlights: codeInfo.submittedContent || [] };
            
            this.setData({
              // 从数据库获取的分析结果
              analysis: resultData.analysis || [],
              statistics: resultData.statistics || { totalTalents: 0, uniqueTalents: 0, topTalents: [] },
              wordCloud: resultData.wordCloud || [],
              radarData: resultData.radarData || [],
              roseData: resultData.roseData || [],
              celebrities: resultData.celebrities || [],
              topFiveAnalysis: resultData.topFiveAnalysis || resultData.topThreeAnalysis || { talents: [], relatedHighlights: [] },
              topThreeAnalysis: resultData.topThreeAnalysis || resultData.topFiveAnalysis || { talents: [], relatedHighlights: [] },
              // 计数数据
              highlightCount: resultData.highlightCount || 0,
              talentCount: resultData.talentCount || 0,
              typeCount: resultData.typeCount || 0,
              // 用户基本信息和高光时刻
              highlights: userInfo.highlights || [],
              age: userInfo.age || 30,
              careerStatus: userInfo.careerStatus || '',
              careerConfusion: userInfo.careerConfusion || '',
              education: userInfo.education || '',
              // 加载完成
              isLoading: false,
              analysisStatus: '天赋报告已加载完成'
            });
          
          // 显示加载完成提示
          wx.showToast({
            title: '天赋报告加载成功',
            icon: 'success',
            duration: 2000
          });
          
        } else {
          console.warn('未找到对应的结果数据或记录未提交');
          this.setData({
            isLoading: false,
            analysisStatus: '未找到已保存的报告',
            highlightCount: 0,
            talentCount: 0,
            typeCount: 0
          });
          wx.showToast({ title: '未找到已保存的报告', icon: 'none' });
        }
      })
      .catch(err => {
        console.error('加载结果数据失败：', err);
        this.setData({
          isLoading: false,
          analysisStatus: '加载失败，请重试'
        });
        wx.showToast({ title: '加载失败，请重试', icon: 'none' });
      });
  },

  onTabChange(e) {
    var tab = e.currentTarget.dataset.tab;
    if (!tab) return;
    this.setData({ activeTab: tab });
  },

  // 为词云添加颜色属性
  addWordColors(wordCloud) {
    return wordCloud.map(function(word, index) {
      // 根据value值分配颜色 - 暖橙色系
      var color = '#D35400'; // 默认深橙色
      
      if (word.value >= 8) {
        color = '#E67E22'; // 主橙色 - 最高频
      } else if (word.value >= 6) {
        color = '#F39C12'; // 亮橙色 - 高频
      } else if (word.value >= 4) {
        color = '#FF6D00'; // 暖橙色 - 中高频
      } else if (word.value >= 2) {
        color = '#FF8F00'; // 浅橙色 - 中频
      } else {
        color = '#FFB74D'; // 淡橙色 - 低频
      }
      
      var result = {};
      for (var key in word) {
        if (word.hasOwnProperty(key)) {
          result[key] = word[key];
        }
      }
      result.color = color;
      return result;
    });
  },

  // 生成雷达图数据
  generateRadarData(statistics) {
    if (!statistics || !statistics.frequencyDistribution) {
      return [];
    }
    
    // 取前6个最重要的天赋特征
    var topTalents = statistics.frequencyDistribution.slice(0, 6);
    var maxValue = Math.max.apply(null, topTalents.map(function(t) { return t.count; }));
    
    // 雷达图容器尺寸
    var containerSize = 500; // rpx - 与CSS保持一致
    var center = containerSize / 2;
    var dataRadius = 150; // 数据点半径 - 进一步缩小让数据更集中
    var labelRadius = 200; // 标签半径 - 进一步缩小让标签更集中
    
    return topTalents.map(function(talent, index) {
      // 计算角度，均匀分布在圆周上
      var angle = (index * 2 * Math.PI / topTalents.length) - Math.PI / 2; // 从顶部开始
      
      // 计算半径，根据数值归一化到0-1
      var normalizedValue = talent.count / maxValue;
      var radius = normalizedValue; // 0-1之间的值
      
      // 计算数据点坐标
      var dataX = center + Math.cos(angle) * radius * dataRadius;
      var dataY = center + Math.sin(angle) * radius * dataRadius;
      
      // 计算标签坐标
      var labelX = center + Math.cos(angle) * labelRadius;
      var labelY = center + Math.sin(angle) * labelRadius;
      
      // 计算数据点大小，与频率成正比
      var minSize = 16; // 最小尺寸 (rpx)
      var maxSize = 32; // 最大尺寸 (rpx)
      var pointSize = minSize + (normalizedValue * (maxSize - minSize));
      
      // 计算文字大小，与频率成正比
      var minFontSize = 20; // 最小字体大小 (rpx)
      var maxFontSize = 32; // 最大字体大小 (rpx)
      var fontSize = minFontSize + (normalizedValue * (maxFontSize - minFontSize));
      
              return {
          talent: talent.talent,
          value: talent.count,
          angle: angle,
          radius: radius,
          percentage: talent.percentage,
          x: dataX,
          y: dataY,
          labelX: labelX,
          labelY: labelY,
          pointSize: pointSize, // 添加点的大小信息
          fontSize: fontSize // 添加字体大小信息
        };
    });
  },

  // 生成天赋玫瑰图数据
  generateRoseData(frequencyDistribution) {
    if (!frequencyDistribution || frequencyDistribution.length === 0) {
      return [];
    }
    
    // 取前15个最重要的天赋特征用于玫瑰图
    var topTalents = frequencyDistribution.slice(0, 15);
    
    return topTalents.map(function(talent, index) {
      return {
        talent: talent.talent,
        value: talent.count,
        percentage: talent.percentage,
        index: index
      };
    });
  },

  // 取前5个Top天赋，简化版本
  normalizeTopTalents(sortedTopTalents, totalTalents) {
    var limit = Math.min(5, sortedTopTalents.length);
    var trimmed = sortedTopTalents.slice(0, limit);
    
    return trimmed.map(function(t, index) {
      var percentage = trimmed.length > 0 ? 
        Number(((t.count / trimmed[0].count) * 100).toFixed(1)) :
        Number(((t.count / (totalTalents || 1)) * 100).toFixed(1));
      
      // 简化的等级系统
      var gemLevel = '';
      var gemIcon = '';
      var gemColor = '';
      
      if (index === 0) {
        gemLevel = 'SSS';
        gemIcon = '💎';
        gemColor = '#FF6B6B';
      } else if (index === 1) {
        gemLevel = 'SS';
        gemIcon = '💎';
        gemColor = '#4ECDC4';
      } else if (index === 2) {
        gemLevel = 'S';
        gemIcon = '💎';
        gemColor = '#45B7D1';
      } else {
        gemLevel = 'A';
        gemIcon = '⭐';
        gemColor = '#96CEB4';
      }
      
      var result = {};
      for (var key in t) {
        if (t.hasOwnProperty(key)) {
          result[key] = t[key];
        }
      }
      result.percentage = percentage;
      result.gemLevel = gemLevel;
      result.gemIcon = gemIcon;
      result.gemColor = gemColor;
      // 根据等级分配钻石数量
      var iconCount;
      if (gemLevel === 'SSS') {
        iconCount = 5;
      } else if (gemLevel === 'SS') {
        iconCount = 4;
      } else if (gemLevel === 'S') {
        iconCount = 3;
      } else {
        iconCount = 3;
      }
      
      result.iconCount = iconCount;
      return result;
    });
  },

  runAnalysis(highlights, userId) {
    this.setData({ isLoading: true });
    
    // ===== 位置一：基础天赋匹配分析（模拟） =====
    // 这里调用 analyzeHighlights() 进行基础天赋匹配
    // 输出：statistics, wordCloud, celebrities, topFiveAnalysis.talents
    console.log('开始基础天赋匹配分析...');
    
    analyzeHighlights(highlights, userId)
      .then(function(res) {
        console.log('基础天赋匹配完成:', res);
        
        // 计算topFive相关高光
        var sortedTopTalents = (res.statistics && res.statistics.frequencyDistribution) ? res.statistics.frequencyDistribution : [];
        console.log('sortedTopTalents:', sortedTopTalents);
        var normalizedTopTalents = this.normalizeTopTalents(sortedTopTalents, (res.statistics && res.statistics.totalTalents) || 0);
        console.log('normalizedTopTalents:', normalizedTopTalents);
        // 从normalizedTopTalents中获取天赋名称
        var topFiveNames = normalizedTopTalents.map(function(t) { return t.talent; });
        console.log('topFiveNames:', topFiveNames);

        var relatedHighlights = [];
        (res.analysis || []).forEach(function(item) {
          (topFiveNames || []).forEach(function(talent) {
            if ((item.talents || []).indexOf(talent) !== -1) {
              relatedHighlights.push({ talent: talent, highlight: item.moment });
            }
          });
        });

        // 为名人补充matchedTalents和圣杯评级
        var celebrities = (res.celebrities || []).map(function(c) {
          // 使用原始的matchedTalents数据，如果不存在则计算
          var matchedTalents = c.matchedTalents || (c.talents || []).filter(function(t) { return topFiveNames.indexOf(t) !== -1; });
          var matchScore = matchedTalents.length;
          var maxPossibleMatch = Math.min(topFiveNames.length, (c.talents || []).length);
          var matchRate = maxPossibleMatch > 0 ? Math.round((matchScore / maxPossibleMatch) * 100) : 0;
          
          // 圣杯评级系统：3-5个圣杯
          var cupCount = 3;
          var cupIcon = '🏆';
          var cupColor = '#CD7F32'; // 铜色
          
          if (matchRate >= 90) {
            cupCount = 5;
            cupColor = '#FFD700'; // 金色
          } else if (matchRate >= 75) {
            cupCount = 4;
            cupColor = '#C0C0C0'; // 银色
          } else if (matchRate >= 50) {
            cupCount = 3;
            cupColor = '#CD7F32'; // 铜色
          }
          
          var result = {};
          for (var key in c) {
            if (c.hasOwnProperty(key)) {
              result[key] = c[key];
            }
          }
          result.matchedTalents = matchedTalents;
          result.matchScore = matchScore;
          result.matchRate = matchRate;
          result.cupCount = cupCount;
          result.cupIcon = cupIcon;
          result.cupColor = cupColor;
          return result;
        });

        // 为词云添加颜色
        var coloredWordCloud = this.addWordColors(res.wordCloud || []);

        // 生成雷达图数据
        var radarData = this.generateRadarData(res.statistics);

        // 初始化topFiveAnalysis结构
        var topFiveAnalysis = { 
          talents: topFiveNames, 
          relatedHighlights: relatedHighlights,
          deepseekResults: {} // 初始化DeepSeek结果对象
        };

        console.log('设置基础数据:', {
          topFiveAnalysis: topFiveAnalysis,
          topFiveNames: topFiveNames,
          relatedHighlights: relatedHighlights
        });

      this.setData({   


          analysis: res.analysis || [],
          statistics: {
            totalTalents: (res.statistics && res.statistics.totalTalents) || 0,
            uniqueTalents: (res.statistics && res.statistics.uniqueTalents) || 0,
            topTalents: normalizedTopTalents
          },
          wordCloud: coloredWordCloud,
          radarData: radarData || [],
          roseData: this.generateRoseData(res.statistics.frequencyDistribution || []),
          celebrities: celebrities || [],
          topFiveAnalysis: topFiveAnalysis || { talents: [], relatedHighlights: [] },
          topThreeAnalysis: topFiveAnalysis || { talents: [], relatedHighlights: [] },
          highlightCount: highlights.length || 0,
          talentCount: (res.statistics && res.statistics.totalTalents) || 0,
          typeCount: (res.statistics && res.statistics.uniqueTalents) || 0,
          isLoading: false
        });
        
        // 保存结果数据到数据库
        this.saveResultDataToDB();
        
        // ===== 位置二：王牌天赋深度分析（真实DeepSeek API） =====
        // 这里调用 autoAnalyzeTalents() 进行DeepSeek AI分析
        // 输出：topFiveAnalysis.deepseekResults
        console.log('开始王牌天赋深度分析...');
        
        this.autoAnalyzeTalents();
        
        // ===== 位置三：名人个性化建议生成（真实DeepSeek API） =====
        // 这里调用 generateCelebrityAdvice() 为每个名人生成个性化建议
        console.log('开始生成名人个性化建议...');
        
        this.generateCelebrityAdvice();
      }.bind(this))
      .catch(function(error) {
        console.error('基础天赋匹配失败:', error);
        this.setData({ isLoading: false });
        wx.showToast({ title: '分析失败，请重试', icon: 'none' });
      }.bind(this));
  },

  // 调用DeepSeek API分析天赋推导
  analyzeTalentWithDeepSeek(talent, highlights) {
    var that = this;
    
    // 构建提示词
    var prompt = `你是一位专业的人生咨询师，拥有丰富的职业发展经验。面对一位高学历女性，她在一线城市、名校或知名公司工作，目前感到迷茫，希望通过发掘自己的天赋和热爱来建立商业模式，实现自己的价值。

你需要从她的人生高光时刻中，为她揭示这个天赋特征：${talent}

重要提示：
1. 用咨询师温暖、专业的语调，让她感受到被理解和支持
2. 她可能没有意识到自己做成的事对别人来说是困难的，你要告诉她，做成这个事有哪些难点
3. 你要帮她分析，她做成这个事情，调用了哪些底层天赋
4. 一定要结合具体的高光时刻内容，有逻辑地分析，让她感觉到说到点子上，而且都是她的真实情况，并不谄媚虚伪，非常真诚
5. 语言要温暖、专业、富有启发性，像在为她揭示内在的宝藏
6. 让她感受到自己内在潜力的觉醒，对未来充满信心

高光时刻：
${highlights.map(function(h, index) {
  return `${index + 1}. ${h}`;
}).join('\n')}

请用温暖、专业、富有启发性的咨询师语调回答，字数控制在200字以内。`;

    // 调用真实的DeepSeek API
    return new Promise(function(resolve, reject) {
      console.log('开始调用DeepSeek API，天赋:', talent);
      
      wx.request({
        url: 'https://api.deepseek.com/v1/chat/completions',
        method: 'POST',
        header: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer sk-f2e36bf643d74d2dbcb1fdcfb6993ca9'
        },
        data: {
          model: 'deepseek-chat',
          messages: [
            {
              role: 'system',
              content: '你是专业的人生咨询师。'
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          max_tokens: 300,
          temperature: 0.8
        },
        success: function(res) {
          console.log('DeepSeek API响应:', res);
          
          if (res.statusCode === 200 && res.data && res.data.choices && res.data.choices.length > 0) {
            var analysis = res.data.choices[0].message.content;
            console.log('API分析成功:', analysis);
            resolve(analysis);
          } else {
            // API调用成功但返回数据异常
            console.warn('DeepSeek API返回数据异常:', res);
            reject(new Error('API返回数据异常: ' + res.statusCode));
          }
        },
        fail: function(error) {
          console.error('DeepSeek API调用失败:', error);
          reject(error);
        }
      });
    });
  },

  // 保存结果数据到数据库
  saveResultDataToDB() {
    const { activationCode, userId, highlights, analysis, statistics, wordCloud, radarData, roseData, celebrities, topFiveAnalysis, highlightCount, talentCount, typeCount } = this.data;
    
    // 检查是否有激活码
    if (!activationCode) {
      console.log('没有激活码，不保存结果数据');
      return;
    }
    
    console.log('准备保存结果数据到数据库...');
    
    // 格式化当前时间为YYYY-MM-DD HH:mm:ss格式，仿照form页面中的submittedTime
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const formattedTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    
    // 构建要保存的数据，确保每个字段都有默认值，避免null值
    const resultData = {
      analysis: analysis || [],
      statistics: statistics || { totalTalents: 0, uniqueTalents: 0, topTalents: [] },
      wordCloud: wordCloud || [],
      radarData: radarData || [],
      roseData: roseData || [],
      celebrities: celebrities || [],
      topFiveAnalysis: topFiveAnalysis || { talents: [], relatedHighlights: [] },
      highlightCount: highlightCount || 0,
      talentCount: talentCount || 0,
      typeCount: typeCount || 0,
      saveTime: formattedTime
    };
    
    // 查询并更新数据库
    activationCodeCollection
      .where({
        activationCode: activationCode
      })
      .get()
      .then(res => {
        if (res.data.length > 0) {
          const codeInfo = res.data[0];
          
          // 修复：直接替换整个resultData对象，避免在null上创建字段
          // 当数据库中的resultData为null时，必须直接替换整个对象，而不是尝试在null上创建字段
          // 这是MongoDB/云开发数据库的特性，避免"Cannot create field 'analysis' in element {resultData: null}"错误
          return activationCodeCollection
            .doc(codeInfo._id)
            .update({
              data: {
                // 直接替换整个resultData对象
                resultData: resultData,
                resultSaveTime: formattedTime // 保存结果的时间，格式：YYYY-MM-DD HH:mm:ss
              }
            });
        } else {
          throw new Error('未找到对应的激活码记录');
        }
      })
      .then(() => {
        console.log('结果数据保存成功');
      })
      .catch(err => {
        console.error('保存结果数据失败：', err);
      });
  },
  
  // 自动分析天赋（页面加载时调用）
  autoAnalyzeTalents() {
    var that = this;
    var topFiveTalents = this.data.topFiveAnalysis.talents || [];
    var highlights = this.data.highlights;
    
    console.log('开始王牌天赋深度分析，数量:', topFiveTalents.length);
    console.log('天赋列表:', topFiveTalents);
    console.log('高光时刻数量:', highlights.length);
    
    if (topFiveTalents.length === 0) {
      console.warn('没有天赋需要深度分析');
      return;
    }
    
    // 为每个天赋自动触发DeepSeek AI分析
    topFiveTalents.forEach(function(talent, index) {
      console.log('开始分析天赋', index + 1, ':', talent);
      
      that.analyzeTalentWithDeepSeek(talent, highlights)
        .then(function(analysis) {
          console.log('DeepSeek分析成功:', talent, analysis);
          
          // 更新分析结果到topFiveAnalysis
          var updatedTopFive = that.data.topFiveAnalysis;
          if (!updatedTopFive.deepseekResults) {
            updatedTopFive.deepseekResults = {};
          }
          updatedTopFive.deepseekResults[talent] = analysis;
          
          console.log('更新后的topFiveAnalysis:', updatedTopFive);
          
          that.setData({
            topFiveAnalysis: updatedTopFive,
            analysisStatus: '天赋报告分析加载完成'
          });
          
          // 保存更新后的分析结果到数据库
          that.saveResultDataToDB();
          
          // 显示加载完成弹窗
          wx.showToast({
            title: '天赋报告分析加载完成',
            icon: 'success',
            duration: 2000
          });
        })
        .catch(function(error) {
          console.error('DeepSeek分析失败:', talent, error);
          
          // 显示错误信息给用户
          wx.showToast({ 
            title: 'AI分析失败，请检查网络或稍后重试', 
            icon: 'none',
            duration: 3000
          });
          
          // 在界面上显示错误状态
          var updatedTopFive = that.data.topFiveAnalysis;
          if (!updatedTopFive.deepseekResults) {
            updatedTopFive.deepseekResults = {};
          }
          updatedTopFive.deepseekResults[talent] = 'AI分析暂时不可用，请稍后重试。';
          
          that.setData({
            topFiveAnalysis: updatedTopFive
          });
        });
    });
  },

  // 生成名人个性化建议
  generateCelebrityAdvice() {
    var that = this;
    var celebrities = this.data.celebrities || [];
    var userInfo = {
      age: this.data.age,
      careerStatus: this.data.careerStatus,
      careerConfusion: this.data.careerConfusion,
      education: this.data.education
    };
    
    console.log('开始为名人生成个性化建议，数量:', celebrities.length);
    console.log('用户信息:', userInfo);
    console.log('名人数据:', celebrities);
    
    if (celebrities.length === 0) {
      console.warn('没有名人需要生成建议');
      wx.showToast({
        title: '没有匹配的名人',
        icon: 'none'
      });
      return;
    }
    
    // 为每个名人生成个性化建议
    celebrities.forEach(function(celebrity, index) {
      console.log('开始为名人生成建议', index + 1, ':', celebrity.name);
      
      generatePersonalizedAdvice(celebrity, userInfo, that.data.highlights)
        .then(function(advice) {
          console.log('名人建议生成成功:', celebrity.name, advice);
          
          // 更新名人数据
          var updatedCelebrities = that.data.celebrities;
          var celebrityIndex = updatedCelebrities.findIndex(function(c) { return c.name === celebrity.name; });
          
          if (celebrityIndex !== -1) {
            updatedCelebrities[celebrityIndex].personalizedAdvice = advice;
            
            that.setData({
              celebrities: updatedCelebrities
            });
            
            // 保存更新后的数据到数据库
            that.saveResultDataToDB();
            
            console.log('名人建议更新成功:', celebrity.name);
            
            // 显示成功提示
            wx.showToast({
              title: celebrity.name + '的建议已生成',
              icon: 'success',
              duration: 1500
            });
          } else {
            console.error('找不到对应的名人:', celebrity.name);
          }
        })
        .catch(function(error) {
          console.error('名人建议生成失败:', celebrity.name, error);
          console.error('错误详情:', error);
          
          // 显示错误信息给用户
          wx.showToast({ 
            title: celebrity.name + '建议生成失败', 
            icon: 'none',
            duration: 2000
          });
        });
    });
  },

  // 测试名人建议生成
  testCelebrityAdvice() {
    console.log('手动测试名人建议生成');
    console.log('当前名人数据:', this.data.celebrities);
    console.log('当前用户信息:', {
      age: this.data.age,
      careerStatus: this.data.careerStatus,
      careerConfusion: this.data.careerConfusion,
      education: this.data.education
    });
    
    if (this.data.celebrities && this.data.celebrities.length > 0) {
      this.generateCelebrityAdvice();
    } else {
      wx.showToast({
        title: '没有名人数据',
        icon: 'none'
      });
    }
  },

  // 分析天赋按钮点击事件（保留用于手动重新分析）
  analyzeTalent(e) {
    var talent = e.currentTarget.dataset.talent;
    var index = e.currentTarget.dataset.index;
    var highlights = this.data.highlights;
    
    // 调用DeepSeek分析
    this.analyzeTalentWithDeepSeek(talent, highlights)
      .then(function(analysis) {
        // 更新分析结果
        var updatedTopFive = this.data.topFiveAnalysis;
        if (!updatedTopFive.deepseekResults) {
          updatedTopFive.deepseekResults = {};
        }
        updatedTopFive.deepseekResults[talent] = analysis;
        
        this.setData({
          topFiveAnalysis: updatedTopFive
        });
        
        // 保存更新后的分析结果到数据库
        this.saveResultDataToDB();
        
        wx.showToast({
          title: '分析完成',
          icon: 'success'
        });
      }.bind(this))
      .catch(function(error) {
        console.error('DeepSeek分析失败:', error);
        wx.showToast({
          title: '分析失败，请重试',
          icon: 'none'
        });
      }.bind(this));
  },

  generateReport() {
    var userId = this.data.userId;
    var highlights = this.data.highlights;
    var statistics = this.data.statistics;
    var wordCloud = this.data.wordCloud;
    var celebrities = this.data.celebrities;
    var topFiveAnalysis = this.data.topFiveAnalysis;
    var analysis = this.data.analysis;

    if (!highlights || highlights.length === 0) {
      wx.showToast({ title: '没有可生成的内容', icon: 'none' });
      return;
    }

    var now = new Date();
    var topTalentsText = (statistics.topTalents || [])
      .map(function(t, idx) { return (idx + 1) + '. ' + t.talent + ' - 在您的经历中多次展现'; })
      .join('\n');

    var relatedText = (topFiveAnalysis.talents || [])
      .map(function(talent, idx) {
        var items = (topFiveAnalysis.relatedHighlights || []).filter(function(i) { return i.talent === talent; });
        var list = items.map(function(i) { return '  • ' + i.highlight; }).join('\n');
        return (idx + 1) + '. ' + talent + '\n' + list;
      })
      .join('\n');

    var celebText = (celebrities || [])
      .slice(0, 3)
      .map(function(c, idx) { return (idx + 1) + '. ' + c.name + '\n   ' + c.description + '\n   与您相似的天赋：' + (c.matchedTalents || []).join('、'); })
      .join('\n');

    var detailsText = (analysis || [])
      .map(function(item, idx) { return '人生闪光点 ' + (idx + 1) + ': ' + item.moment + '\n体现的天赋：' + (item.talents || []).join('、'); })
      .join('\n');

    var reportContent = '✨ 天赋特征深度分析报告 ✨\n\n亲爱的朋友，这是一份基于您人生高光时刻的专业分析报告。\n\n📊 分析概览\n• 您的人生高光时刻：' + highlights.length + ' 个\n• 发现的天赋特征：' + (statistics.totalTalents || 0) + ' 个\n• 独特天赋类型：' + (statistics.uniqueTalents || 0) + ' 种\n• 最突出的天赋：' + ((statistics.topTalents && statistics.topTalents[0] && statistics.topTalents[0].talent) || '待发现') + ' (在您的经历中多次出现)\n\n🏆 核心天赋特征\n' + topTalentsText + '\n\n🌟 名人榜样参考\n' + celebText + '\n\n📝 详细天赋解读\n' + detailsText + '\n\n💡 个人成长建议\n基于您的天赋特征，建议您：\n• 充分发挥这些与生俱来的优势\n• 寻找能够体现天赋特征的发展机会\n• 通过持续练习让天赋更加突出\n• 将天赋转化为个人品牌和商业价值\n\n愿这份报告能帮助您更好地认识自己，开启人生的新篇章！✨';

    wx.setClipboardData({
      data: reportContent,
      success: function() {
        wx.showToast({ title: '报告已复制到剪贴板', icon: 'success' });
      },
      fail: function() {
        wx.showToast({ title: '复制失败', icon: 'none' });
      }
    });
  },

  // 分享给朋友
  onShareAppMessage: function() {
    const { activationCode, statistics } = this.data;
    const topTalent = statistics.topTalents && statistics.topTalents[0] ? statistics.topTalents[0].talent : '天赋潜能';
    
    return {
      title: '我发现了自己的隐藏天赋：' + topTalent + '，快来看看你的天赋特质吧！',
      path: '/pages/index/index',
      imageUrl: '', // 可以添加分享图片路径
      success: function(res) {
        console.log('分享成功', res);
      },
      fail: function(res) {
        console.log('分享失败', res);
      }
    };
  },

  // 分享到朋友圈
  onShareTimeline: function() {
    const { activationCode, statistics } = this.data;
    const topTalent = statistics.topTalents && statistics.topTalents[0] ? statistics.topTalents[0].talent : '天赋潜能';
    
    return {
      title: '我的天赋特质分析：发现了自己的隐藏优势 - ' + topTalent, 
      query: 'share=true',
      path: '/pages/index/index',
      imageUrl: '' // 可以添加分享图片路径
    };
  },
  
  // 返回form页面并传递激活码
  backToForm: function() {
    const { activationCode } = this.data;
    wx.navigateTo({
      url: `/pages/form/form?activationCode=${encodeURIComponent(activationCode)}&returnFromResult=true`
    });
  },

  // 返回activation页面
  backToActivation: function() {
    wx.navigateTo({
      url: '/pages/activation/activation'
    });
  },

  // 生成长图并保存到相册
  generateAndSaveImage: function() {
    var that = this;
    
    // 显示加载提示
    wx.showLoading({
      title: '正在生成图片...',
    });
    
    // 获取系统信息，用于设置Canvas尺寸
    wx.getSystemInfo({
      success: function(res) {
        var systemInfo = res;
        // 创建Canvas上下文
        const ctx = wx.createCanvasContext('shareCanvas');
        
        // 设置Canvas背景色
        ctx.setFillStyle('#FFF8F0');
        ctx.fillRect(0, 0, that.data.canvasWidth, that.data.canvasHeight);
        
        // 绘制页面内容到Canvas
        that.drawReportToCanvas(ctx, systemInfo);
        
        // 绘制完成后，生成图片并保存到相册
        ctx.draw(false, function() {
          // 生成图片
          wx.canvasToTempFilePath({
            canvasId: 'shareCanvas',
            success: function(res) {
              // 保存图片到相册
              wx.saveImageToPhotosAlbum({
                filePath: res.tempFilePath,
                success: function() {
                  wx.hideLoading();
                  wx.showToast({
                    title: '图片已保存到相册',
                    icon: 'success'
                  });
                },
                fail: function(err) {
                  wx.hideLoading();
                  console.error('保存图片失败:', err);
                  wx.showToast({
                    title: '保存失败，请重试',
                    icon: 'none'
                  });
                  
                  // 如果是因为用户拒绝授权，引导用户授权
                  if (err.errMsg.indexOf('auth deny') >= 0) {
                    wx.showModal({
                      title: '提示',
                      content: '需要您授权保存图片到相册',
                      success: function(res) {
                        if (res.confirm) {
                          wx.openSetting({
                            success: function(settingRes) {
                              if (settingRes.authSetting['scope.writePhotosAlbum']) {
                                wx.showToast({
                                  title: '请重新点击保存图片',
                                  icon: 'none'
                                });
                              }
                            }
                          });
                        }
                      }
                    });
                  }
                }
              });
            },
            fail: function(err) {
              wx.hideLoading();
              console.error('生成图片失败:', err);
              wx.showToast({
                title: '生成失败，请重试',
                icon: 'none'
              });
            }
          });
        });
      },
      fail: function(err) {
        wx.hideLoading();
        console.error('获取系统信息失败:', err);
        wx.showToast({
          title: '生成失败，请重试',
          icon: 'none'
        });
      }
    });
  },
  
  // 将报告内容绘制到Canvas
  drawReportToCanvas: function(ctx, systemInfo) {
    const { 
      highlightCount, 
      talentCount, 
      typeCount, 
      analysisStatus, 
      age, 
      education, 
      careerStatus, 
      careerConfusion,
      statistics,
      roseData,
      celebrities,
      topFiveAnalysis
    } = this.data;
    
    // 绘制标题
    ctx.setFontSize(48);
    ctx.setFillStyle('#333');
    ctx.setTextAlign('center');
    ctx.fillText('天赋探索报告', this.data.canvasWidth / 2, 100);
    
    // 绘制副标题
    ctx.setFontSize(28);
    ctx.setFillStyle('#666');
    ctx.setTextAlign('center');
    const subtitle = `基于${highlightCount}条高光时刻 发现了${talentCount}个天赋特征 涵盖${typeCount}种不同类型`;
    ctx.fillText(subtitle, this.data.canvasWidth / 2, 150);
    
    // 绘制分析状态
    ctx.setFontSize(30);
    ctx.setFillStyle('#000000');
    ctx.setTextAlign('center');
    ctx.fillText(analysisStatus, this.data.canvasWidth / 2, 200);
    
    // 绘制用户基本信息
    ctx.setFontSize(32);
    ctx.setFillStyle('#333');
    ctx.setTextAlign('left');
    ctx.fillText('用户基本信息', 50, 270);
    
    // 绘制信息项
    ctx.setFontSize(28);
    ctx.setFillStyle('#666');
    ctx.fillText(`年龄：${age}岁`, 50, 320);
    ctx.fillText(`学历：${education || '未填写'}`, 50, 360);
    ctx.fillText(`职业状态：${careerStatus || '未填写'}`, 50, 400);
    ctx.fillText(`职业困惑：${careerConfusion || '未填写'}`, 50, 440);
    
    // 绘制统计信息
    ctx.setFontSize(32);
    ctx.setFillStyle('#333');
    ctx.fillText('统计概览', 50, 500);
    
    // 绘制统计项
    const stats = [
      { label: '高光时刻', value: highlightCount },
      { label: '识别天赋', value: statistics.totalTalents || 0 },
      { label: '独特类型', value: statistics.uniqueTalents || 0 }
    ];
    
    const statWidth = this.data.canvasWidth / stats.length;
    stats.forEach((stat, index) => {
      const x = statWidth * (index + 0.5);
      ctx.setFontSize(40);
      ctx.setFillStyle('#E67E22');
      ctx.setTextAlign('center');
      ctx.fillText(stat.value.toString(), x, 580);
      ctx.setFontSize(28);
      ctx.setFillStyle('#666');
      ctx.fillText(stat.label, x, 620);
    });
    
    // 绘制核心天赋特征
    if (statistics.topTalents && statistics.topTalents.length > 0) {
      ctx.setFontSize(32);
      ctx.setFillStyle('#333');
      ctx.setTextAlign('left');
      ctx.fillText('核心天赋特征', 50, 680);
      
      // 绘制天赋列表
      let yOffset = 730;
      statistics.topTalents.slice(0, 5).forEach((talent, index) => {
        // 绘制排名
        ctx.setFontSize(28);
        ctx.setFillStyle(talent.gemColor || '#E67E22');
        ctx.fillText(`${index + 1}.`, 50, yOffset);
        
        // 绘制天赋名称
        ctx.setFillStyle('#333');
        ctx.fillText(talent.talent, 90, yOffset);
        
        // 绘制进度条
        ctx.setFillStyle('#F5F5F5');
        ctx.fillRect(90, yOffset + 10, 500, 15);
        ctx.setFillStyle(talent.gemColor || '#E67E22');
        ctx.fillRect(90, yOffset + 10, (talent.percentage / 100) * 500, 15);
        
        yOffset += 60;
      });
    }
    
    // 绘制玫瑰图特征区域
    if (roseData && roseData.length > 0) {
      // 调整yOffset为合适的值，确保不与上方内容重叠
      yOffset = yOffset > 0 ? yOffset + 40 : 950;
      ctx.setFontSize(32);
      ctx.setFillStyle('#333');
      ctx.setTextAlign('left');
      ctx.fillText('玫瑰图天赋特征', 50, yOffset);
      
      yOffset += 40;
      // 绘制玫瑰图特征列表（简化版，用文字列表表示）
      roseData.slice(0, 8).forEach((item, index) => {
        ctx.setFontSize(28);
        ctx.setFillStyle('#666');
        ctx.setTextAlign('left');
        ctx.fillText(`${index + 1}. ${item.talent} (${item.percentage || 0}%)`, 50, yOffset + index * 50);
      });
      yOffset += 8 * 50 + 20;
    }
    
    // 绘制名人匹配特征区域
    if (celebrities && celebrities.length > 0) {
      yOffset = yOffset > 0 ? yOffset + 40 : 1350;
      ctx.setFontSize(32);
      ctx.setFillStyle('#333');
      ctx.setTextAlign('left');
      ctx.fillText('名人匹配特征', 50, yOffset);
      
      yOffset += 40;
      // 绘制名人匹配列表
      celebrities.slice(0, 3).forEach((celebrity, index) => {
        // 绘制名人姓名
        ctx.setFontSize(28);
        ctx.setFillStyle('#E67E22');
        ctx.fillText(`${index + 1}. ${celebrity.name}`, 50, yOffset + index * 100);
        
        // 绘制匹配度
        ctx.setFontSize(24);
        ctx.setFillStyle('#666');
        ctx.fillText(`匹配度: ${celebrity.matchRate || 0}%`, 50, yOffset + 35 + index * 100);
        
        // 绘制相似天赋
        const matchedTalents = (celebrity.matchedTalents || []).join('、');
        ctx.fillText(`相似天赋: ${matchedTalents}`, 50, yOffset + 70 + index * 100);
      });
      yOffset += 3 * 100 + 20;
    }
    
    // 绘制王牌天赋特征区域
    if (topFiveAnalysis && topFiveAnalysis.talents && topFiveAnalysis.talents.length > 0) {
      yOffset = yOffset > 0 ? yOffset + 40 : 1800;
      ctx.setFontSize(32);
      ctx.setFillStyle('#333');
      ctx.setTextAlign('left');
      ctx.fillText('王牌天赋特征', 50, yOffset);
      
      yOffset += 40;
      // 绘制王牌天赋列表
      topFiveAnalysis.talents.slice(0, 5).forEach((talent, index) => {
        ctx.setFontSize(28);
        ctx.setFillStyle('#F39C12'); // 金黄色，突出王牌天赋
        ctx.fillText(`${index + 1}. ${talent.name || talent}`, 50, yOffset + index * 60);
        
        // 如果有相关高光时刻，显示部分信息
        if (topFiveAnalysis.relatedHighlights && topFiveAnalysis.relatedHighlights[index]) {
          const highlight = topFiveAnalysis.relatedHighlights[index];
          const shortHighlight = highlight.length > 30 ? highlight.substring(0, 30) + '...' : highlight;
          ctx.setFontSize(24);
          ctx.setFillStyle('#999');
          ctx.fillText(`相关高光: ${shortHighlight}`, 90, yOffset + 35 + index * 60);
        }
      });
      yOffset += 5 * 60 + 20;
    }
    
    // 绘制底部团队信息
    ctx.setFontSize(24);
    ctx.setFillStyle('#999');
    ctx.setTextAlign('center');
    ctx.fillText('本天赋报告由Melodz团队提供', this.data.canvasWidth / 2, 3200 - 100);
  }

});