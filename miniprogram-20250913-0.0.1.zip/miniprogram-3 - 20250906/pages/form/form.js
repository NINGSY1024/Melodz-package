const TEST_SAMPLES = [
  "在大学期间，我独自策划并执行了一场500人的公益活动...",
  "工作第二年，我主动提出优化公司的客户服务流程...",
  "在一次重要的商业谈判中，对方态度强硬且条件苛刻...",
  "面对团队内部的严重分歧，我组织了多次沟通会议...",
  "在产品发布前一周发现重大技术问题...",
  "参加国际学术会议时，我用流利的英语向来自20多个国家的专家学者展示了我的研究成果...",
  "在公司面临财务危机时，我主动承担起寻找新投资的任务...",
  "发现市场上缺乏针对特定用户群体的产品后...",
  "在一次跨部门项目中，我协调了来自5个不同部门的20多名同事...",
  "面对公司的数字化转型挑战，我主动学习了大数据分析技术..."
];

// 引入云开发数据库集合 
const { activationCodeCollection } = require('../../utils/cloud');

Page({
  data: {
    highlights: ['', '', '', '', ''],
    activationCode: '' // 存储从激活页面传递过来的激活码
  },

  // 页面加载时获取激活码参数
  onLoad(options) {
    // 从页面参数中获取激活码
    if (options.activationCode) {
      this.setData({
        activationCode: options.activationCode
      });
    }
  },
 

 
  // 高光时刻输入事件
  onHighlightInput(e) {
    const index = e.currentTarget.dataset.index; 
    const newHighlights = this.data.highlights.slice(); 
    newHighlights[index] = e.detail.value; 
    this.setData({  highlights: newHighlights });
  },
 
  // 加载测试样例（加载全部样例）
  loadSample() {
    this.setData({  highlights: TEST_SAMPLES.slice() });
  },
 
  // 添加更多高光时刻输入框，最多10个
  addMoreHighlight() {
    if (this.data.highlights.length >= 10) {
      wx.showToast({
        title: '最多只能添加10个高光时刻',
        icon: 'none'
      });
      return;
    }
    const newHighlights = this.data.highlights.slice();
    newHighlights.push('');
    this.setData({
      highlights: newHighlights
    });
  },
 
  // 提交表单并跳转
  submitForm() {
    const { highlights, activationCode } = this.data; 

    const filledHighlights = highlights.filter(function(h) { return h.trim(); }); 

    // 至少填写5个高光时刻，最多10个
    if (filledHighlights.length  < 5) {
      wx.showToast({  title: '请至少填写五个高光时刻', icon: 'none' });
      return;
    }
    if (filledHighlights.length > 10) {
      wx.showToast({  title: '高光时刻不能超过10个', icon: 'none' });
      return;
    }

    // 显示加载动画
    wx.showLoading({
      title: '提交中...',
      mask: true
    });

    // 格式化当前时间为YYYY-MM-DD HH:mm:ss格式
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const formattedTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

    // 查询并更新数据库
    activationCodeCollection
      .where({
        activationCode: activationCode
      })
      .get()
      .then(res => {
        if (res.data.length > 0) {
          const codeInfo = res.data[0];
          
          // 更新数据库字段
          return activationCodeCollection
            .doc(codeInfo._id)
            .update({
              data: {
                isSubmitted: true, // 设置为已提交
                submittedContent: highlights, // 设置高光时刻内容
                submittedTime: formattedTime // 设置提交时间
              }
            });
        } else {
          throw new Error('未找到对应的激活码记录');
        }
      })
      .then(() => {
        wx.hideLoading();
        console.log('数据库更新成功');
        
        // 更新成功后跳转到结果页面
        wx.navigateTo({ 
          url: '/pages/result/result?' +
               'highlights=' + encodeURIComponent(JSON.stringify(highlights)) +
               '&activationCode=' + encodeURIComponent(activationCode) 
        });
      })
      .catch(err => {
        wx.hideLoading();
        wx.showToast({
          title: '提交失败，请重试',
          icon: 'none',
          duration: 2000
        });
        console.error('提交表单失败：', err);
        console.error('错误代码:', err.errCode);
        console.error('错误信息:', err.errMsg);
      });
  }
});