// result.js  

var api = require('../../utils/api.js');
var analyzeHighlights = api.analyzeHighlights;

// 引入云开发数据库集合 
const { activationCodeCollection } = require('../../utils/cloud');

Page({ 
  data: {
    isLoading: true,
    activeTab: 'overview',
    userId: '',
    activationCode: '',
    // 分析状态提示文本
    analysisStatus: '耐心等待10s后，天赋报告完成',
    // 输入的高光时刻数组
    highlights: [],
    // 分析结果
    analysis: [], // [{ moment, talents }]
    statistics: { totalTalents: 0, uniqueTalents: 0, topTalents: [] },
    wordCloud: [], // [{ text, value, frequency, x, y }]
    radarData: [], // [{ talent, value, angle, radius }]
    roseData: [], // [{ talent, value, percentage }] 玫瑰图数据
    celebrities: [], // 由utils计算，含matchRate
    topThreeAnalysis: { talents: [], relatedHighlights: [] },
    // 概览用计数
    highlightCount: 0,
    talentCount: 0,
    typeCount: 0
  },

  onLoad(options) {
    var highlightsParam = [];
    var activationCode = options && options.activationCode ? decodeURIComponent(options.activationCode) : '';
    
    if (options && options.highlights) {
      try {
        highlightsParam = JSON.parse(decodeURIComponent(options.highlights));
      } catch (e) {
        highlightsParam = [];
      }
    }

    // 回退到本地存储
    if (!highlightsParam || highlightsParam.length === 0) {
      var formData = wx.getStorageSync('talentFormData') || {};
      if (formData.highlights && typeof formData.highlights === 'string') {
        highlightsParam = formData.highlights.split('\n');
      }
    }

    var filteredHighlights = (highlightsParam || []).filter(function(h) { return typeof h === 'string' && h.trim(); });

    // 设置用户ID为激活码
    this.setData({ userId: activationCode });
    
    // 设置激活码
    if (activationCode) {
      this.setData({ activationCode: activationCode });
      console.log('接收的激活码:', activationCode);
    }

    if (filteredHighlights.length === 0) {
    this.setData({  
        isLoading: false,
        highlights: [],
        highlightCount: 0,
        talentCount: 0,
        typeCount: 0
      });
      wx.showToast({ title: '没有找到高光时刻', icon: 'none' });
      return;
    }

    this.setData({ highlights: filteredHighlights });
    this.runAnalysis(filteredHighlights, this.data.userId || activationCode);
  },

  onTabChange(e) {
    var tab = e.currentTarget.dataset.tab;
    if (!tab) return;
    this.setData({ activeTab: tab });
  },

  // 为词云添加颜色属性
  addWordColors(wordCloud) {
    return wordCloud.map(function(word, index) {
      // 根据value值分配颜色 - 暖橙色系
      var color = '#D35400'; // 默认深橙色
      
      if (word.value >= 8) {
        color = '#E67E22'; // 主橙色 - 最高频
      } else if (word.value >= 6) {
        color = '#F39C12'; // 亮橙色 - 高频
      } else if (word.value >= 4) {
        color = '#FF6D00'; // 暖橙色 - 中高频
      } else if (word.value >= 2) {
        color = '#FF8F00'; // 浅橙色 - 中频
      } else {
        color = '#FFB74D'; // 淡橙色 - 低频
      }
      
      var result = {};
      for (var key in word) {
        if (word.hasOwnProperty(key)) {
          result[key] = word[key];
        }
      }
      result.color = color;
      return result;
    });
  },

  // 生成雷达图数据
  generateRadarData(statistics) {
    if (!statistics || !statistics.frequencyDistribution) {
      return [];
    }
    
    // 取前6个最重要的天赋特征
    var topTalents = statistics.frequencyDistribution.slice(0, 6);
    var maxValue = Math.max.apply(null, topTalents.map(function(t) { return t.count; }));
    
    // 雷达图容器尺寸
    var containerSize = 500; // rpx - 与CSS保持一致
    var center = containerSize / 2;
    var dataRadius = 150; // 数据点半径 - 进一步缩小让数据更集中
    var labelRadius = 200; // 标签半径 - 进一步缩小让标签更集中
    
    return topTalents.map(function(talent, index) {
      // 计算角度，均匀分布在圆周上
      var angle = (index * 2 * Math.PI / topTalents.length) - Math.PI / 2; // 从顶部开始
      
      // 计算半径，根据数值归一化到0-1
      var normalizedValue = talent.count / maxValue;
      var radius = normalizedValue; // 0-1之间的值
      
      // 计算数据点坐标
      var dataX = center + Math.cos(angle) * radius * dataRadius;
      var dataY = center + Math.sin(angle) * radius * dataRadius;
      
      // 计算标签坐标
      var labelX = center + Math.cos(angle) * labelRadius;
      var labelY = center + Math.sin(angle) * labelRadius;
      
      // 计算数据点大小，与频率成正比
      var minSize = 16; // 最小尺寸 (rpx)
      var maxSize = 32; // 最大尺寸 (rpx)
      var pointSize = minSize + (normalizedValue * (maxSize - minSize));
      
      // 计算文字大小，与频率成正比
      var minFontSize = 20; // 最小字体大小 (rpx)
      var maxFontSize = 32; // 最大字体大小 (rpx)
      var fontSize = minFontSize + (normalizedValue * (maxFontSize - minFontSize));
      
              return {
          talent: talent.talent,
          value: talent.count,
          angle: angle,
          radius: radius,
          percentage: talent.percentage,
          x: dataX,
          y: dataY,
          labelX: labelX,
          labelY: labelY,
          pointSize: pointSize, // 添加点的大小信息
          fontSize: fontSize // 添加字体大小信息
        };
    });
  },

  // 生成天赋玫瑰图数据
  generateRoseData(frequencyDistribution) {
    if (!frequencyDistribution || frequencyDistribution.length === 0) {
      return [];
    }
    
    // 取前15个最重要的天赋特征用于玫瑰图
    var topTalents = frequencyDistribution.slice(0, 15);
    
    return topTalents.map(function(talent, index) {
      return {
        talent: talent.talent,
        value: talent.count,
        percentage: talent.percentage,
        index: index
      };
    });
  },

  // 取5-8个Top天赋，简化版本
  normalizeTopTalents(sortedTopTalents, totalTalents) {
    var limit = Math.min(8, Math.max(5, sortedTopTalents.length));
    var trimmed = sortedTopTalents.slice(0, limit);
    
    return trimmed.map(function(t, index) {
      var percentage = trimmed.length > 0 ? 
        Number(((t.count / trimmed[0].count) * 100).toFixed(1)) :
        Number(((t.count / (totalTalents || 1)) * 100).toFixed(1));
      
      // 简化的等级系统
      var gemLevel = '';
      var gemIcon = '';
      var gemColor = '';
      
      if (index === 0) {
        gemLevel = 'SSS';
        gemIcon = '💎';
        gemColor = '#FF6B6B';
      } else if (index === 1) {
        gemLevel = 'SS';
        gemIcon = '💎';
        gemColor = '#4ECDC4';
      } else if (index === 2) {
        gemLevel = 'S';
        gemIcon = '💎';
        gemColor = '#45B7D1';
      } else {
        gemLevel = 'A';
        gemIcon = '⭐';
        gemColor = '#96CEB4';
      }
      
      var result = {};
      for (var key in t) {
        if (t.hasOwnProperty(key)) {
          result[key] = t[key];
        }
      }
      result.percentage = percentage;
      result.gemLevel = gemLevel;
      result.gemIcon = gemIcon;
      result.gemColor = gemColor;
      // 根据等级分配钻石数量
      var iconCount;
      if (gemLevel === 'SSS') {
        iconCount = 5;
      } else if (gemLevel === 'SS') {
        iconCount = 4;
      } else if (gemLevel === 'S') {
        iconCount = 3;
      } else {
        iconCount = 3;
      }
      
      result.iconCount = iconCount;
      return result;
    });
  },

  runAnalysis(highlights, userId) {
    this.setData({ isLoading: true });
    
    // ===== 位置一：基础天赋匹配分析（模拟） =====
    // 这里调用 analyzeHighlights() 进行基础天赋匹配
    // 输出：statistics, wordCloud, celebrities, topThreeAnalysis.talents
    console.log('开始基础天赋匹配分析...');
    
    analyzeHighlights(highlights, userId)
      .then(function(res) {
        console.log('基础天赋匹配完成:', res);
        
        // 计算topThree相关高光
        var sortedTopTalents = (res.statistics && res.statistics.frequencyDistribution) ? res.statistics.frequencyDistribution : [];
        var normalizedTopTalents = this.normalizeTopTalents(sortedTopTalents, (res.statistics && res.statistics.totalTalents) || 0);
        var topThreeNames = normalizedTopTalents.slice(0, 3).map(function(t) { return t.talent; });

        var relatedHighlights = [];
        (res.analysis || []).forEach(function(item) {
          (topThreeNames || []).forEach(function(talent) {
            if ((item.talents || []).indexOf(talent) !== -1) {
              relatedHighlights.push({ talent: talent, highlight: item.moment });
            }
          });
        });

        // 为名人补充matchedTalents和圣杯评级
        var celebrities = (res.celebrities || []).map(function(c) {
          var matchedTalents = (c.talents || []).filter(function(t) { return topThreeNames.indexOf(t) !== -1; });
          var matchScore = matchedTalents.length;
          var maxPossibleMatch = Math.min(topThreeNames.length, c.talents.length);
          var matchRate = maxPossibleMatch > 0 ? Math.round((matchScore / maxPossibleMatch) * 100) : 0;
          
          // 圣杯评级系统：3-5个圣杯
          var cupCount = 3;
          var cupIcon = '🏆';
          var cupColor = '#CD7F32'; // 铜色
          
          if (matchRate >= 90) {
            cupCount = 5;
            cupColor = '#FFD700'; // 金色
          } else if (matchRate >= 75) {
            cupCount = 4;
            cupColor = '#C0C0C0'; // 银色
          } else if (matchRate >= 50) {
            cupCount = 3;
            cupColor = '#CD7F32'; // 铜色
          }
          
          var result = {};
          for (var key in c) {
            if (c.hasOwnProperty(key)) {
              result[key] = c[key];
            }
          }
          result.matchedTalents = matchedTalents;
          result.matchScore = matchScore;
          result.matchRate = matchRate;
          result.cupCount = cupCount;
          result.cupIcon = cupIcon;
          result.cupColor = cupColor;
          return result;
        });

        // 为词云添加颜色
        var coloredWordCloud = this.addWordColors(res.wordCloud || []);

        // 生成雷达图数据
        var radarData = this.generateRadarData(res.statistics);

        // 初始化topThreeAnalysis结构
        var topThreeAnalysis = { 
          talents: topThreeNames, 
          relatedHighlights: relatedHighlights,
          deepseekResults: {} // 初始化DeepSeek结果对象
        };

        console.log('设置基础数据:', {
          topThreeAnalysis: topThreeAnalysis,
          topThreeNames: topThreeNames,
          relatedHighlights: relatedHighlights
        });

      this.setData({   


          analysis: res.analysis || [],
          statistics: {
            totalTalents: (res.statistics && res.statistics.totalTalents) || 0,
            uniqueTalents: (res.statistics && res.statistics.uniqueTalents) || 0,
            topTalents: normalizedTopTalents
          },
          wordCloud: coloredWordCloud,
          radarData: radarData || [],
          roseData: this.generateRoseData(res.statistics.frequencyDistribution || []),
          celebrities: celebrities || [],
          topThreeAnalysis: topThreeAnalysis || { talents: [], relatedHighlights: [] },
          highlightCount: highlights.length || 0,
          talentCount: (res.statistics && res.statistics.totalTalents) || 0,
          typeCount: (res.statistics && res.statistics.uniqueTalents) || 0,
          isLoading: false
        });
        
        // 保存结果数据到数据库
        this.saveResultDataToDB();
        
        // ===== 位置二：王牌天赋深度分析（真实DeepSeek API） =====
        // 这里调用 autoAnalyzeTalents() 进行DeepSeek AI分析
        // 输出：topThreeAnalysis.deepseekResults
        console.log('开始王牌天赋深度分析...');
        
        this.autoAnalyzeTalents();
      }.bind(this))
      .catch(function(error) {
        console.error('基础天赋匹配失败:', error);
        this.setData({ isLoading: false });
        wx.showToast({ title: '分析失败，请重试', icon: 'none' });
      }.bind(this));
  },

  // 调用DeepSeek API分析天赋推导
  analyzeTalentWithDeepSeek(talent, highlights) {
    var that = this;
    
    // 构建提示词
    var prompt = `你是一位专业的人生咨询师，拥有丰富的职业发展经验。面对一位高学历女性，她在一线城市、名校或知名公司工作，目前感到迷茫，希望通过发掘自己的天赋和热爱来建立商业模式，实现自己的价值。

你需要从她的人生高光时刻中，为她揭示这个天赋特征：${talent}

重要提示：
1. 用咨询师温暖、专业的语调，让她感受到被理解和支持
2. 她可能并没有意识到自己拥有这样的天赋，但通过你的分析，应该让她有一种豁然开朗的感觉
3. 一定要引用具体的高光时刻内容，让她有"原来如此"的顿悟感
4. 语言要温暖、专业、富有启发性，像在为她揭示内在的宝藏
5. 让她感受到自己内在潜力的觉醒，对未来充满信心

高光时刻：
${highlights.map(function(h, index) {
  return `${index + 1}. ${h}`;
}).join('\n')}

请用温暖、专业、富有启发性的咨询师语调回答，字数控制在200字以内。`;

    // 调用真实的DeepSeek API
    return new Promise(function(resolve, reject) {
      console.log('开始调用DeepSeek API，天赋:', talent);
      
      wx.request({
        url: 'https://api.deepseek.com/v1/chat/completions',
        method: 'POST',
        header: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer sk-f2e36bf643d74d2dbcb1fdcfb6993ca9'
        },
        data: {
          model: 'deepseek-chat',
          messages: [
            {
              role: 'system',
              content: '你是专业的人生咨询师。'
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          max_tokens: 300,
          temperature: 0.8
        },
        success: function(res) {
          console.log('DeepSeek API响应:', res);
          
          if (res.statusCode === 200 && res.data && res.data.choices && res.data.choices.length > 0) {
            var analysis = res.data.choices[0].message.content;
            console.log('API分析成功:', analysis);
            resolve(analysis);
          } else {
            // API调用成功但返回数据异常
            console.warn('DeepSeek API返回数据异常:', res);
            reject(new Error('API返回数据异常: ' + res.statusCode));
          }
        },
        fail: function(error) {
          console.error('DeepSeek API调用失败:', error);
          reject(error);
        }
      });
    });
  },

  // 保存结果数据到数据库
  saveResultDataToDB() {
    const { activationCode, userId, highlights, analysis, statistics, wordCloud, radarData, roseData, celebrities, topThreeAnalysis, highlightCount, talentCount, typeCount } = this.data;
    
    // 检查是否有激活码
    if (!activationCode) {
      console.log('没有激活码，不保存结果数据');
      return;
    }
    
    console.log('准备保存结果数据到数据库...');
    
    // 格式化当前时间为YYYY-MM-DD HH:mm:ss格式，仿照form页面中的submittedTime
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const formattedTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    
    // 构建要保存的数据，确保每个字段都有默认值，避免null值
    const resultData = {
      analysis: analysis || [],
      statistics: statistics || { totalTalents: 0, uniqueTalents: 0, topTalents: [] },
      wordCloud: wordCloud || [],
      radarData: radarData || [],
      roseData: roseData || [],
      celebrities: celebrities || [],
      topThreeAnalysis: topThreeAnalysis || { talents: [], relatedHighlights: [] },
      highlightCount: highlightCount || 0,
      talentCount: talentCount || 0,
      typeCount: typeCount || 0,
      saveTime: formattedTime
    };
    
    // 查询并更新数据库
    activationCodeCollection
      .where({
        activationCode: activationCode
      })
      .get()
      .then(res => {
        if (res.data.length > 0) {
          const codeInfo = res.data[0];
          
          // 修复：直接替换整个resultData对象，避免在null上创建字段
          // 当数据库中的resultData为null时，必须直接替换整个对象，而不是尝试在null上创建字段
          // 这是MongoDB/云开发数据库的特性，避免"Cannot create field 'analysis' in element {resultData: null}"错误
          return activationCodeCollection
            .doc(codeInfo._id)
            .update({
              data: {
                // 直接替换整个resultData对象
                resultData: resultData,
                resultSaveTime: formattedTime // 保存结果的时间，格式：YYYY-MM-DD HH:mm:ss
              }
            });
        } else {
          throw new Error('未找到对应的激活码记录');
        }
      })
      .then(() => {
        console.log('结果数据保存成功');
      })
      .catch(err => {
        console.error('保存结果数据失败：', err);
      });
  },
  
  // 自动分析天赋（页面加载时调用）
  autoAnalyzeTalents() {
    var that = this;
    var topThreeTalents = this.data.topThreeAnalysis.talents || [];
    var highlights = this.data.highlights;
    
    console.log('开始王牌天赋深度分析，数量:', topThreeTalents.length);
    console.log('天赋列表:', topThreeTalents);
    console.log('高光时刻数量:', highlights.length);
    
    if (topThreeTalents.length === 0) {
      console.warn('没有天赋需要深度分析');
      return;
    }
    
    // 为每个天赋自动触发DeepSeek AI分析
    topThreeTalents.forEach(function(talent, index) {
      console.log('开始分析天赋', index + 1, ':', talent);
      
      that.analyzeTalentWithDeepSeek(talent, highlights)
        .then(function(analysis) {
          console.log('DeepSeek分析成功:', talent, analysis);
          
          // 更新分析结果到topThreeAnalysis
          var updatedTopThree = that.data.topThreeAnalysis;
          if (!updatedTopThree.deepseekResults) {
            updatedTopThree.deepseekResults = {};
          }
          updatedTopThree.deepseekResults[talent] = analysis;
          
          console.log('更新后的topThreeAnalysis:', updatedTopThree);
          
          that.setData({
            topThreeAnalysis: updatedTopThree,
            analysisStatus: '天赋报告分析加载完成'
          });
          
          // 显示加载完成弹窗
          wx.showToast({
            title: '天赋报告分析加载完成',
            icon: 'success',
            duration: 2000
          });
        })
        .catch(function(error) {
          console.error('DeepSeek分析失败:', talent, error);
          
          // 显示错误信息给用户
          wx.showToast({ 
            title: 'AI分析失败，请检查网络或稍后重试', 
            icon: 'none',
            duration: 3000
          });
          
          // 在界面上显示错误状态
          var updatedTopThree = that.data.topThreeAnalysis;
          if (!updatedTopThree.deepseekResults) {
            updatedTopThree.deepseekResults = {};
          }
          updatedTopThree.deepseekResults[talent] = 'AI分析暂时不可用，请稍后重试。';
          
          that.setData({
            topThreeAnalysis: updatedTopThree
          });
        });
    });
  },

  // 分析天赋按钮点击事件（保留用于手动重新分析）
  analyzeTalent(e) {
    var talent = e.currentTarget.dataset.talent;
    var index = e.currentTarget.dataset.index;
    var highlights = this.data.highlights;
    
    // 调用DeepSeek分析
    this.analyzeTalentWithDeepSeek(talent, highlights)
      .then(function(analysis) {
        // 更新分析结果
        var updatedTopThree = this.data.topThreeAnalysis;
        if (!updatedTopThree.deepseekResults) {
          updatedTopThree.deepseekResults = {};
        }
        updatedTopThree.deepseekResults[talent] = analysis;
        
        this.setData({
          topThreeAnalysis: updatedTopThree
        });
        
        wx.showToast({
          title: '分析完成',
          icon: 'success'
        });
      }.bind(this))
      .catch(function(error) {
        console.error('DeepSeek分析失败:', error);
        wx.showToast({
          title: '分析失败，请重试',
          icon: 'none'
        });
      }.bind(this));
  },

  generateReport() {
    var userId = this.data.userId;
    var highlights = this.data.highlights;
    var statistics = this.data.statistics;
    var wordCloud = this.data.wordCloud;
    var celebrities = this.data.celebrities;
    var topThreeAnalysis = this.data.topThreeAnalysis;
    var analysis = this.data.analysis;

    if (!highlights || highlights.length === 0) {
      wx.showToast({ title: '没有可生成的内容', icon: 'none' });
      return;
    }

    var now = new Date();
    var topTalentsText = (statistics.topTalents || [])
      .map(function(t, idx) { return (idx + 1) + '. ' + t.talent + ' - 在您的经历中多次展现'; })
      .join('\n');

    var relatedText = (topThreeAnalysis.talents || [])
      .map(function(talent, idx) {
        var items = (topThreeAnalysis.relatedHighlights || []).filter(function(i) { return i.talent === talent; });
        var list = items.map(function(i) { return '  • ' + i.highlight; }).join('\n');
        return (idx + 1) + '. ' + talent + '\n' + list;
      })
      .join('\n');

    var celebText = (celebrities || [])
      .slice(0, 3)
      .map(function(c, idx) { return (idx + 1) + '. ' + c.name + '\n   ' + c.description + '\n   与您相似的天赋：' + (c.matchedTalents || []).join('、'); })
      .join('\n');

    var detailsText = (analysis || [])
      .map(function(item, idx) { return '人生闪光点 ' + (idx + 1) + ': ' + item.moment + '\n体现的天赋：' + (item.talents || []).join('、'); })
      .join('\n');

    var reportContent = '✨ 天赋特征深度分析报告 ✨\n\n亲爱的朋友，这是一份基于您人生高光时刻的专业分析报告。\n\n📊 分析概览\n• 您的人生高光时刻：' + highlights.length + ' 个\n• 发现的天赋特征：' + (statistics.totalTalents || 0) + ' 个\n• 独特天赋类型：' + (statistics.uniqueTalents || 0) + ' 种\n• 最突出的天赋：' + ((statistics.topTalents && statistics.topTalents[0] && statistics.topTalents[0].talent) || '待发现') + ' (在您的经历中多次出现)\n\n🏆 核心天赋特征\n' + topTalentsText + '\n\n🌟 名人榜样参考\n' + celebText + '\n\n📝 详细天赋解读\n' + detailsText + '\n\n💡 个人成长建议\n基于您的天赋特征，建议您：\n• 充分发挥这些与生俱来的优势\n• 寻找能够体现天赋特征的发展机会\n• 通过持续练习让天赋更加突出\n• 将天赋转化为个人品牌和商业价值\n\n愿这份报告能帮助您更好地认识自己，开启人生的新篇章！✨';

    wx.setClipboardData({
      data: reportContent,
      success: function() {
        wx.showToast({ title: '报告已复制到剪贴板', icon: 'success' });
      },
      fail: function() {
        wx.showToast({ title: '复制失败', icon: 'none' });
      }
    });
  }
});